/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        surface: {
          0: 'var(--surface-0)',
          1: 'var(--surface-1)',
          2: 'var(--surface-2)',
          3: 'var(--surface-3)',
          4: 'var(--surface-4)',
          5: 'var(--surface-5)',
        },
        line: {
          subtle: 'var(--line-subtle)',
          DEFAULT: 'var(--line-default)',
          strong: 'var(--line-strong)',
        },
        fg: {
          hi: 'var(--fg-hi)',
          mid: 'var(--fg-mid)',
          lo: 'var(--fg-lo)',
          dim: 'var(--fg-dim)',
        },
        accent: {
          50: 'var(--accent-50)',
          100: 'var(--accent-100)',
          300: 'var(--accent-300)',
          500: 'var(--accent-500)',
          700: 'var(--accent-700)',
          900: 'var(--accent-900)',
        },
        success: 'var(--success)',
        warning: 'var(--warning)',
        danger: 'var(--danger)',
        info: 'var(--info)',
        deep: {
          sidebar: 'var(--deep-sidebar)',
          hero: 'var(--deep-hero)',
          fab: 'var(--deep-fab)',
        },
      },
      borderColor: {
        DEFAULT: 'var(--line-default)',
      },
      ringColor: {
        DEFAULT: 'var(--accent-500)',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'SF Mono', 'Cascadia Code', 'Menlo', 'Consolas', 'monospace'],
      },
      borderRadius: {
        chip: '6px',
        input: '10px',
        button: '12px',
        'card-sm': '14px',
        card: '16px',
        hero: '20px',
        sheet: '20px',
      },
      transitionTimingFunction: {
        standard: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
        emphasized: 'cubic-bezier(0.32, 0.72, 0, 1)',
      },
      transitionDuration: {
        instant: '100ms',
        standard: '180ms',
        emphasized: '280ms',
        slow: '400ms',
        deliberate: '500ms',
      },
      fontSize: {
        'display': ['28px', { lineHeight: '1.2', letterSpacing: '-0.02em', fontWeight: '600' }],
        'h1': ['22px', { lineHeight: '1.25', letterSpacing: '-0.01em', fontWeight: '600' }],
        'h2': ['17px', { lineHeight: '1.3', fontWeight: '600' }],
        'body': ['14px', { lineHeight: '1.5' }],
        'label': ['13px', { lineHeight: '1.4', fontWeight: '500' }],
        'micro': ['11px', { lineHeight: '1.3', letterSpacing: '0.08em', fontWeight: '600' }],
        'caption': ['12px', { lineHeight: '1.4' }],
        'hero-num': ['52px', { lineHeight: '1.05', letterSpacing: '-0.02em', fontWeight: '600' }],
        'stat-num': ['32px', { lineHeight: '1.1', letterSpacing: '-0.01em', fontWeight: '600' }],
        'timer-num': ['48px', { lineHeight: '1', letterSpacing: '-0.02em', fontWeight: '600' }],
      },
    },
  },
  plugins: [],
};