// Parser input cepat: "bensin 20rb" → Transport 20.000

export interface ParsedTransaction {
  type: 'income' | 'expense';
  amount: number;
  category: string;
}

const INCOME_KEYWORDS: { category: string; keywords: string[] }[] = [
  { category: 'Gaji', keywords: ['gaji', 'gajian', 'payroll', 'thr'] },
  { category: 'Bonus', keywords: ['bonus', 'sampingan', 'freelance', 'proyek', 'honor'] },
];

// URUTAN PENTING: Transport HARUS sebelum Belanja agar "bensin" tidak masuk Belanja.
const EXPENSE_CATEGORIES: { name: string; keywords: string[] }[] = [
  {
    name: 'Transport',
    keywords: [
      'bensin', 'pertalite', 'pertamax', 'solar', 'grab', 'gojek', 'ojek', 'ojol',
      'parkir', 'tol', 'bus', 'angkot', 'kereta', 'tiket',
    ],
  },
  {
    name: 'Tagihan',
    keywords: [
      'listrik', 'pln', 'wifi', 'internet', 'pulsa', 'kuota', 'air', 'pdam',
      'iuran', 'bpjs', 'kos',
    ],
  },
  {
    name: 'Kesehatan',
    keywords: ['obat', 'dokter', 'klinik', 'vitamin', 'masker', 'apotek'],
  },
  {
    name: 'Makan',
    keywords: [
      'makan', 'minum', 'kopi', 'jajan', 'nasi', 'mie', 'ayam', 'bakso', 'sate',
      'gorengan', 'snack', 'golda', 'teh', 'es', 'jus', 'roti', 'sarapan', 'warung',
    ],
  },
  {
    name: 'Belanja',
    keywords: [
      'sabun', 'sayur', 'beras', 'sembako', 'odol', 'sampo', 'deterjen', 'susu',
      'telur', 'gula', 'minyak', 'tissue', 'baju', 'celana',
    ],
  },
  {
    name: 'Hiburan',
    keywords: ['nonton', 'bioskop', 'netflix', 'spotify', 'game', 'topup', 'steam'],
  },
  {
    name: 'Pendidikan',
    keywords: ['buku', 'kursus', 'kuliah', 'spp', 'fotokopi', 'print'],
  },
];

export function parseQuickCapture(input: string): ParsedTransaction | null {
  const text = input.trim();
  if (!text) return null;

  let amount: number | null = null;

  // Rule 1: unit suffix (rb/ribu/k ×1000, jt/juta ×1000000)
  const m1 = text.match(/(\d+(?:[.,]\d+)?)\s*(rb|ribu|k|jt|juta)\b/i);
  if (m1) {
    const raw = m1[1] ?? '0';
    const num = parseFloat(raw.replace(',', '.'));
    const unit = (m1[2] ?? '').toLowerCase();
    if (unit === 'rb' || unit === 'ribu' || unit === 'k') {
      amount = Math.round(num * 1000);
    } else if (unit === 'jt' || unit === 'juta') {
      amount = Math.round(num * 1_000_000);
    }
  }

  // Rule 2: separator ribuan atau 4+ digit polos
  if (amount == null) {
    const m2 = text.match(/\d{1,3}(?:[.,]\d{3})+|\d{4,}/);
    if (m2) {
      const cleaned = (m2[0] ?? '').replace(/[.,]/g, '');
      amount = parseInt(cleaned, 10);
    }
  }

  if (amount == null || !Number.isFinite(amount) || amount <= 0) return null;

  const lower = text.toLowerCase();

  for (const { category, keywords } of INCOME_KEYWORDS) {
    for (const kw of keywords) {
      if (new RegExp(`\\b${kw}\\b`, 'i').test(lower)) {
        return { type: 'income', amount, category };
      }
    }
  }

  for (const { name, keywords } of EXPENSE_CATEGORIES) {
    for (const kw of keywords) {
      if (new RegExp(`\\b${kw}\\b`, 'i').test(lower)) {
        return { type: 'expense', amount, category: name };
      }
    }
  }

  return { type: 'expense', amount, category: 'Lain-lain' };
}