// Semua tipe data dan konstanta. Tidak ada logic di sini.

export type ID = string;
export type DateStr = string;
export type ISODate = string;
export type Theme = 'dark' | 'light';

export type ModuleId =
  | 'beranda' | 'keuangan' | 'tugas' | 'kebiasaan' | 'catatan' | 'jurnal' | 'pengaturan'
  | 'shift' | 'tidur' | 'trading' | 'fokus';

export interface Settings {
  nama: string;
  theme: Theme;
  active_modules: ModuleId[];
  currency: 'IDR';
  daily_water_target_ml: number;
  pomodoro: {
    focus: number;
    short: number;
    long: number;
    long_break_interval: number;
    sound: boolean;
  };
  budget_method: 'safe_daily' | 'zero_based';
}

export type WalletType = 'cash' | 'ewallet' | 'bank';
export interface Wallet {
  id: ID;
  name: string;
  type: WalletType;
  initial_balance: number;
  sort_order: number;
  color?: string;
}

export type TxType = 'income' | 'expense' | 'transfer' | 'adjustment';
export interface Transaction {
  id: ID;
  type: TxType;
  amount: number;
  category: string;
  wallet_id: ID;
  to_wallet_id?: ID;
  sign?: '+' | '-';
  date: DateStr;
  note: string;
  tags?: string[];
  created_at: ISODate;
}

export interface Budget {
  id: ID;
  category: string;
  amount: number;
  period: 'monthly' | 'weekly';
  month?: string;
}

export interface SavingsGoal {
  id: ID;
  name: string;
  target_amount: number;
  current_amount: number;
  deadline?: DateStr;
  color?: string;
  created_at: ISODate;
}

export interface Debt {
  id: ID;
  name: string;
  amount: number;
  type: 'debt' | 'loan';
  due_date?: DateStr;
  paid: boolean;
  notes?: string;
  created_at: ISODate;
}

export type TaskCategory = 'rs' | 'koding' | 'pribadi' | 'lainnya';
export type TaskPriority = 'low' | 'medium' | 'high';
export type TaskStatus = 'todo' | 'done' | 'archived';
export interface Subtask {
  id: ID;
  title: string;
  done: boolean;
}
export interface Task {
  id: ID;
  title: string;
  category: TaskCategory;
  priority: TaskPriority;
  status: TaskStatus;
  due_date?: DateStr;
  notes?: string;
  subtasks?: Subtask[];
  created_at: ISODate;
  updated_at: ISODate;
}

export type HabitFreq = 'daily' | 'weekly' | 'custom';
export interface Habit {
  id: ID;
  name: string;
  icon?: string;
  color?: string;
  frequency: HabitFreq;
  target_per_week?: number;
  reminder_time?: string;
  created_at: ISODate;
}
export interface HabitLog {
  id: ID;
  habit_id: ID;
  date: DateStr;
  created_at: ISODate;
}

export interface Note {
  id: ID;
  title: string;
  content: string;
  color?: string;
  tags?: string[];
  pinned?: boolean;
  created_at: ISODate;
  updated_at: ISODate;
}

export type Mood = 1 | 2 | 3 | 4 | 5;
export interface Journal {
  id: ID;
  title: string;
  content: string;
  date: DateStr;
  mood: Mood;
  gratitude?: string;
  tags?: string[];
  created_at: ISODate;
  updated_at: ISODate;
}

export type ShiftType = 'pagi' | 'siang' | 'malam' | 'libur' | 'off';
export interface Shift {
  id: ID;
  date: DateStr;
  shift_type: ShiftType;
  start_time?: string;
  end_time?: string;
  notes?: string;
}

export interface SleepLog {
  id: ID;
  sleep_at: ISODate;
  wake_at: ISODate;
  duration_min: number;
  quality: 1 | 2 | 3 | 4 | 5;
  notes?: string;
  created_at: ISODate;
}

export interface Trade {
  id: ID;
  datetime: ISODate;
  pair: string;
  direction: 'buy' | 'sell';
  entry?: number;
  sl?: number;
  tp?: number;
  exit?: number;
  lot: number;
  pl: number;
  r?: number;
  result: 'profit' | 'loss' | 'be';
  setup?: string;
  timeframe?: string;
  session?: string;
  emotion?: string;
  screenshot_url?: string;
  notes?: string;
  created_at: ISODate;
}

export type PomodoroType = 'focus' | 'short_break' | 'long_break';
export interface PomodoroSession {
  id: ID;
  started_at: ISODate;
  type: PomodoroType;
  duration_min: number;
  completed: boolean;
  task_id?: ID;
}

export interface AppState {
  version: 1;
  settings: Settings;
  wallets: Wallet[];
  transactions: Transaction[];
  budgets: Budget[];
  savings_goals: SavingsGoal[];
  debts: Debt[];
  tasks: Task[];
  habits: Habit[];
  habit_logs: HabitLog[];
  notes: Note[];
  journal: Journal[];
  shifts: Shift[];
  sleep_logs: SleepLog[];
  trades: Trade[];
  pomodoro_sessions: PomodoroSession[];
}

export const MODULE_LABELS: Record<ModuleId, string> = {
  beranda: 'Beranda',
  keuangan: 'Keuangan',
  tugas: 'Tugas',
  kebiasaan: 'Kebiasaan',
  catatan: 'Catatan',
  jurnal: 'Jurnal',
  pengaturan: 'Pengaturan',
  shift: 'Shift',
  tidur: 'Tidur',
  trading: 'Trading',
  fokus: 'Fokus',
};

export const CORE_MODULES: ModuleId[] = [
  'beranda', 'keuangan', 'tugas', 'kebiasaan', 'catatan', 'jurnal', 'pengaturan',
];

export const OPTIONAL_MODULES: ModuleId[] = ['shift', 'tidur', 'trading', 'fokus'];

export const EXPENSE_CATEGORY_OPTIONS = [
  'Makan', 'Transport', 'Belanja', 'Tagihan', 'Kesehatan',
  'Hiburan', 'Pendidikan', 'Lain-lain',
];

export const INCOME_CATEGORY_OPTIONS = ['Gaji', 'Bonus', 'Lain-lain'];

export const TASK_CATEGORY_LABELS: Record<TaskCategory, string> = {
  rs: 'RS',
  koding: 'Koding',
  pribadi: 'Pribadi',
  lainnya: 'Lainnya',
};