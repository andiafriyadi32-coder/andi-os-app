import type { SleepLog } from '../types';

export function sleepDuration(sleepAt: Date, wakeAt: Date): number {
  let diffMs = wakeAt.getTime() - sleepAt.getTime();
  if (diffMs < 0) diffMs += 24 * 60 * 60 * 1000;
  return Math.round(diffMs / 60_000);
}

export interface SleepStats {
  avg7: number;
  avg14: number;
  totalWeek: number;
  belowThreshold: boolean;
}

export function sleepStats(logs: SleepLog[], today: Date): SleepStats {
  const sevenAgo = new Date(today);
  sevenAgo.setDate(sevenAgo.getDate() - 7);
  const fourteenAgo = new Date(today);
  fourteenAgo.setDate(fourteenAgo.getDate() - 14);

  const last7 = logs.filter((l) => new Date(l.wake_at) >= sevenAgo);
  const last14 = logs.filter((l) => new Date(l.wake_at) >= fourteenAgo);

  const avg7 = last7.length
    ? last7.reduce((s, l) => s + l.duration_min, 0) / last7.length
    : 0;
  const avg14 = last14.length
    ? last14.reduce((s, l) => s + l.duration_min, 0) / last14.length
    : 0;
  const totalWeek = last7.reduce((s, l) => s + l.duration_min, 0);

  return { avg7, avg14, totalWeek, belowThreshold: avg7 < 7 * 60 && avg7 > 0 };
}