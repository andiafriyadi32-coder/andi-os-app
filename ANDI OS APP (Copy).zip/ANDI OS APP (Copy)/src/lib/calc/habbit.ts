import type { Habit, HabitLog, ID } from '../types';
import { fromDateStr, toDateStr } from '../format';

export interface HabitStreakResult {
  current: number;
  longest: number;
  completionRate30: number;
}

export function habitStreak(
  logs: HabitLog[],
  habitId: ID,
  today: Date
): HabitStreakResult {
  const set = new Set<string>();
  for (const l of logs) if (l.habit_id === habitId) set.add(l.date);

  let current = 0;
  const cursor = new Date(today);
  if (!set.has(toDateStr(cursor))) {
    cursor.setDate(cursor.getDate() - 1);
  }
  while (set.has(toDateStr(cursor))) {
    current++;
    cursor.setDate(cursor.getDate() - 1);
  }

  const sorted = Array.from(set).sort();
  let longest = 0;
  let run = 0;
  let prev: Date | null = null;
  for (const ds of sorted) {
    const d = fromDateStr(ds);
    if (prev) {
      const diffDays = Math.round(
        (d.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24)
      );
      run = diffDays === 1 ? run + 1 : 1;
    } else {
      run = 1;
    }
    if (run > longest) longest = run;
    prev = d;
  }
  if (current > longest) longest = current;

  let logged = 0;
  const t = new Date(today);
  for (let i = 0; i < 30; i++) {
    if (set.has(toDateStr(t))) logged++;
    t.setDate(t.getDate() - 1);
  }
  const completionRate30 = (logged / 30) * 100;

  return { current, longest, completionRate30 };
}

export function habitsDoneToday(
  habits: Habit[],
  logs: HabitLog[],
  today: Date
): number {
  const todayStr_ = toDateStr(today);
  const loggedSet = new Set<string>();
  for (const l of logs) if (l.date === todayStr_) loggedSet.add(l.habit_id);
  return habits.reduce((n, h) => (loggedSet.has(h.id) ? n + 1 : n), 0);
}