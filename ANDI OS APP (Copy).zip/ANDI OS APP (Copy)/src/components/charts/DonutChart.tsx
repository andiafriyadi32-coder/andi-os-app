import type { ReactNode } from 'react';

export interface DonutSlice {
  label: string;
  value: number;
  color: string;
}

export interface DonutChartProps {
  slices: DonutSlice[];
  size?: number;
  thickness?: number;
  center?: ReactNode;
}

export function DonutChart({
  slices,
  size = 120,
  thickness = 16,
  center,
}: DonutChartProps) {
  const total = slices.reduce((s, x) => s + x.value, 0);
  const radius = (size - thickness) / 2;
  const circ = 2 * Math.PI * radius;

  const segments: { dash: number; color: string }[] = [];
  for (const s of slices) {
    const pct = total > 0 ? s.value / total : 0;
    const dash = pct * circ;
    segments.push({ dash, color: s.color });
  }

  let acc = 0;

  return (
    <div
      className="relative inline-flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="-rotate-90" aria-hidden>
        {total === 0 ? (
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="var(--line-default)"
            strokeWidth={thickness}
            fill="none"
          />
        ) : (
          segments.map((seg, i) => {
            const start = acc;
            acc += seg.dash;
            return (
              <circle
                key={i}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                stroke={seg.color}
                strokeWidth={thickness}
                fill="none"
                strokeDasharray={`${seg.dash} ${circ - seg.dash}`}
                strokeDashoffset={-start}
              />
            );
          })
        )}
      </svg>
      {center && (
        <div className="absolute inset-0 flex items-center justify-center">{center}</div>
      )}
    </div>
  );
}