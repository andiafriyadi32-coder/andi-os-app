import type { ChartTone } from './LineChart';

export interface BarPoint {
  label: string;
  value: number;
  tone?: ChartTone;
}

export interface BarChartProps {
  data: BarPoint[];
  height?: number;
}

const BAR_FILL: Record<ChartTone, string> = {
  accent: 'bg-accent-500',
  success: 'bg-success',
  danger: 'bg-danger',
  warning: 'bg-warning',
};

export function BarChart({ data, height = 120 }: BarChartProps) {
  if (data.length === 0) return null;
  const max = Math.max(1, ...data.map((d) => Math.abs(d.value)));
  return (
    <div
      className="flex items-end gap-1.5"
      style={{ height }}
      role="img"
      aria-label="Grafik batang"
    >
      {data.map((d, i) => {
        const pct = (Math.abs(d.value) / max) * 100;
        const fill = BAR_FILL[d.tone ?? 'accent'];
        return (
          <div
            key={`${d.label}-${i}`}
            className="flex flex-1 flex-col items-center justify-end gap-1"
          >
            <div
              className={`w-full rounded-sm ${fill} transition-[height] duration-slow ease-emphasized`}
              style={{ height: `${Math.max(2, pct)}%` }}
              title={`${d.label}: ${d.value}`}
            />
            <span className="max-w-full truncate text-[10px] leading-none text-fg-lo">
              {d.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}