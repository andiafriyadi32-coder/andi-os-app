export interface LinePoint {
  label: string;
  value: number;
}

export type ChartTone = 'accent' | 'success' | 'danger' | 'warning';

export interface LineChartProps {
  data: LinePoint[];
  height?: number;
  tone?: ChartTone;
}

const TONE_COLOR: Record<ChartTone, string> = {
  accent: 'var(--accent-500)',
  success: 'var(--success)',
  danger: 'var(--danger)',
  warning: 'var(--warning)',
};

export function LineChart({ data, height = 120, tone = 'accent' }: LineChartProps) {
  if (data.length === 0) return null;

  const width = 300;
  const pad = 8;
  const innerW = width - pad * 2;
  const innerH = height - pad * 2;

  const values = data.map((d) => d.value);
  const rawMin = Math.min(...values);
  const rawMax = Math.max(...values);
  const min = Math.min(0, rawMin);
  const max = Math.max(rawMax, min + 1);
  const range = max - min;

  const xFor = (i: number): number =>
    pad + (i / Math.max(1, data.length - 1)) * innerW;
  const yFor = (v: number): number => pad + innerH - ((v - min) / range) * innerH;

  let linePath = '';
  for (let i = 0; i < data.length; i++) {
    const d = data[i];
    if (!d) continue;
    const x = xFor(i);
    const y = yFor(d.value);
    linePath += `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)} `;
  }

  const firstX = xFor(0);
  const lastX = xFor(data.length - 1);
  const areaPath = `${linePath}L ${lastX.toFixed(2)} ${(pad + innerH).toFixed(
    2
  )} L ${firstX.toFixed(2)} ${(pad + innerH).toFixed(2)} Z`;

  const color = TONE_COLOR[tone];
  const gradientId = `lg-${tone}`;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="w-full"
      preserveAspectRatio="none"
      role="img"
      aria-label="Grafik garis"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={areaPath} fill={`url(#${gradientId})`} stroke="none" />
      <path
        d={linePath}
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </svg>
  );
}