export interface CheckboxProps {
  checked: boolean;
  onChange: (next: boolean) => void;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  ariaLabel?: string;
}

export function Checkbox({
  checked,
  onChange,
  label,
  size = 'md',
  disabled,
  ariaLabel,
}: CheckboxProps) {
  const boxDim = size === 'lg' ? 'h-12 w-12' : size === 'sm' ? 'h-5 w-5' : 'h-6 w-6';
  const iconDim = size === 'lg' ? 'h-6 w-6' : size === 'sm' ? 'h-3 w-3' : 'h-4 w-4';
  return (
    <label
      className={`inline-flex items-center gap-2.5 ${
        disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'
      }`}
    >
      <button
        type="button"
        role="checkbox"
        aria-checked={checked}
        aria-label={ariaLabel}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`flex ${boxDim} shrink-0 items-center justify-center rounded-md border-2 transition-colors duration-instant ease-standard ${
          checked
            ? 'border-accent-500 bg-accent-500'
            : 'border-line-strong bg-transparent hover:border-accent-300'
        }`}
      >
        <svg
          className={`${iconDim} text-white transition-opacity duration-instant ease-standard`}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          aria-hidden
          style={{ opacity: checked ? 1 : 0 }}
        >
          <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      {label && <span className="text-body text-fg-hi">{label}</span>}
    </label>
  );
}