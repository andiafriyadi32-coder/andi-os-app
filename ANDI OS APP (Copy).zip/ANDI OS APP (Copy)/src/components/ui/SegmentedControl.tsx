export interface SegmentedOption<T extends string> {
  value: T;
  label: string;
}

export interface SegmentedControlProps<T extends string> {
  options: SegmentedOption<T>[];
  value: T;
  onChange: (next: T) => void;
  fullWidth?: boolean;
}

export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  fullWidth = false,
}: SegmentedControlProps<T>) {
  return (
    <div
      role="tablist"
      className={`inline-flex rounded-chip border border-line bg-surface-2 p-0.5 ${
        fullWidth ? 'w-full' : ''
      }`}
    >
      {options.map((opt) => (
        <button
          key={opt.value}
          type="button"
          role="tab"
          aria-selected={value === opt.value}
          onClick={() => onChange(opt.value)}
          className={`flex-1 whitespace-nowrap rounded-chip px-3 py-1.5 text-caption font-medium transition-colors duration-standard ease-standard ${
            value === opt.value
              ? 'bg-accent-500 text-white'
              : 'text-fg-mid hover:text-fg-hi'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}