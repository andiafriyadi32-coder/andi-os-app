import type { ReactNode } from 'react';

export interface BentoGridProps {
  children: ReactNode;
  className?: string;
}

export function BentoGrid({ children, className = '' }: BentoGridProps) {
  return (
    <div
      className={`grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 lg:gap-4 ${className}`}
    >
      {children}
    </div>
  );
}

export type BentoSpan = 'sm' | 'md' | 'lg' | 'xl';

export interface BentoCellProps {
  children: ReactNode;
  span?: BentoSpan;
  className?: string;
}

const SPAN_CLASSES: Record<BentoSpan, string> = {
  sm: '',
  md: 'sm:col-span-1 lg:col-span-1',
  lg: 'sm:col-span-2 lg:col-span-2',
  xl: 'sm:col-span-2 lg:col-span-2 lg:row-span-2',
};

export function BentoCell({ children, span = 'sm', className = '' }: BentoCellProps) {
  return <div className={`${SPAN_CLASSES[span]} ${className}`}>{children}</div>;
}