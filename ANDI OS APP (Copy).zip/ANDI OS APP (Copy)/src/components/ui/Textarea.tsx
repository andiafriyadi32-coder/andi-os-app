import { forwardRef, useId, type TextareaHTMLAttributes } from 'react';

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { label, error, hint, id, className = '', rows = 4, ...rest },
  ref
) {
  const autoId = useId();
  const taId = id ?? autoId;
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={taId} className="text-label text-fg-mid">
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        id={taId}
        rows={rows}
        className={`rounded-input border bg-surface-2 px-3.5 py-2.5 text-body text-fg-hi placeholder:text-fg-dim transition-colors duration-standard ease-standard focus:border-accent-500 focus:outline-none focus:ring-1 focus:ring-accent-500 ${
          error ? 'border-danger' : 'border-line'
        } ${className}`}
        {...rest}
      />
      {error ? (
        <span className="text-caption text-danger">{error}</span>
      ) : hint ? (
        <span className="text-caption text-fg-lo">{hint}</span>
      ) : null}
    </div>
  );
});