import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { createPortal } from 'react-dom';

import { subscribeToast } from '../../lib/store';

export interface ToastAction {
  label: string;
  onClick: () => void;
}

interface ToastItem {
  id: string;
  message: string;
  action?: ToastAction;
  duration: number;
}

interface ToastContextValue {
  show: (message: string, opts?: { action?: ToastAction; duration?: number }) => void;
}

const ToastCtx = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const timers = useRef<Map<string, number>>(new Map());

  const dismiss = useCallback((id: string) => {
    const t = timers.current.get(id);
    if (t !== undefined) window.clearTimeout(t);
    timers.current.delete(id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const show = useCallback(
    (message: string, opts?: { action?: ToastAction; duration?: number }) => {
      const id = `t-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const item: ToastItem = {
        id,
        message,
        action: opts?.action,
        duration: opts?.duration ?? (opts?.action ? 5000 : 2500),
      };
      setItems((prev) => [...prev, item]);
      const t = window.setTimeout(() => dismiss(id), item.duration);
      timers.current.set(id, t);
    },
    [dismiss]
  );

  useEffect(() => {
    return subscribeToast((message) => show(message));
  }, [show]);

  useEffect(() => {
    const map = timers.current;
    return () => {
      map.forEach((t) => window.clearTimeout(t));
      map.clear();
    };
  }, []);

  return (
    <ToastCtx.Provider value={{ show }}>
      <style>{`@keyframes aos-slide-up { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }`}</style>
      {children}
      <ToastViewport items={items} onDismiss={dismiss} />
    </ToastCtx.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastCtx);
  if (!ctx) {
    throw new Error('useToast harus dipakai di dalam ToastProvider');
  }
  return ctx;
}

function ToastViewport({
  items,
  onDismiss,
}: {
  items: ToastItem[];
  onDismiss: (id: string) => void;
}) {
  if (items.length === 0) return null;
  return createPortal(
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[60] flex flex-col items-center gap-2 px-4">
      {items.map((item) => (
        <div
          key={item.id}
          className="pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-card border border-line bg-surface-3 px-4 py-3"
          style={{
            animation: 'aos-slide-up 280ms cubic-bezier(0.32, 0.72, 0, 1)',
          }}
        >
          <span className="flex-1 text-body text-fg-hi">{item.message}</span>
          {item.action && (
            <button
              type="button"
              onClick={() => {
                item.action?.onClick();
                onDismiss(item.id);
              }}
              className="rounded-button px-2.5 py-1 text-label font-semibold text-accent-500 hover:text-accent-700"
            >
              {item.action.label}
            </button>
          )}
        </div>
      ))}
    </div>,
    document.body
  );
}