import { useEffect, useState } from 'react';
import {
  BookOpen, CheckSquare, Clock, FileText, Moon, Plus, Settings,
  Timer, TrendingUp, Wallet, type LucideIcon,
} from 'lucide-react';

import { MODULE_LABELS, type ModuleId } from '../../lib/types';
import { useAppState } from '../../lib/store';
import { BottomSheet } from '../ui/BottomSheet';
import { ToastProvider } from '../ui/Toast';

import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { BottomNav } from './BottomNav';

import Beranda from '../../features/beranda';
import Keuangan from '../../features/keuangan';
import Tugas from '../../features/tugas';
import Kebiasaan from '../../features/kebiasaan';
import Catatan from '../../features/catatan';
import Jurnal from '../../features/jurnal';
import Pengaturan from '../../features/pengaturan';
import Shift from '../../features/shift';
import Tidur from '../../features/tidur';
import Trading from '../../features/trading';
import Fokus from '../../features/fokus';

interface ExtraNavItem {
  id: ModuleId;
  icon: LucideIcon;
}

const NAV_EXTRA: ExtraNavItem[] = [
  { id: 'catatan', icon: FileText },
  { id: 'jurnal', icon: BookOpen },
  { id: 'shift', icon: Clock },
  { id: 'tidur', icon: Moon },
  { id: 'trading', icon: TrendingUp },
  { id: 'fokus', icon: Timer },
  { id: 'pengaturan', icon: Settings },
];

function renderModule(id: ModuleId): JSX.Element {
  switch (id) {
    case 'beranda':
      return <Beranda />;
    case 'keuangan':
      return <Keuangan />;
    case 'tugas':
      return <Tugas />;
    case 'kebiasaan':
      return <Kebiasaan />;
    case 'catatan':
      return <Catatan />;
    case 'jurnal':
      return <Jurnal />;
    case 'pengaturan':
      return <Pengaturan />;
    case 'shift':
      return <Shift />;
    case 'tidur':
      return <Tidur />;
    case 'trading':
      return <Trading />;
    case 'fokus':
      return <Fokus />;
    default:
      return <Beranda />;
  }
}

export function AppShell(): JSX.Element {
  const state = useAppState();
  const [module, setModule] = useState<ModuleId>('beranda');
  const [moreOpen, setMoreOpen] = useState(false);
  const [quickOpen, setQuickOpen] = useState(false);

  const enabled = state.settings.active_modules;

  useEffect(() => {
    if (!enabled.includes(module)) {
      setModule('beranda');
    }
  }, [enabled, module]);

  function navigate(target: ModuleId): void {
    setModule(target);
    setMoreOpen(false);
    setQuickOpen(false);
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  const extraVisible = NAV_EXTRA.filter((item) => enabled.includes(item.id));
  const showFab = module === 'beranda';

  return (
    <ToastProvider>
      <div className="relative flex min-h-dvh">
        <Sidebar module={module} enabled={enabled} onNavigate={navigate} />

        <div className="flex min-w-0 flex-1 flex-col">
          <TopBar onAvatar={() => navigate('pengaturan')} />

          <main className="relative z-10 flex-1 pb-24 lg:pb-8">
            <div className="mx-auto w-full max-w-6xl px-4 py-6 lg:px-8">
              {renderModule(module)}
            </div>
          </main>

          <BottomNav
            module={module}
            onNavigate={navigate}
            onMore={() => setMoreOpen(true)}
          />
        </div>

        {showFab && (
          <button
            type="button"
            onClick={() => setQuickOpen(true)}
            aria-label="Aksi cepat"
            className="fixed bottom-24 right-5 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-deep-fab text-white shadow-lg transition-transform duration-standard ease-standard hover:scale-105 active:scale-[0.96] lg:bottom-8 lg:right-8"
          >
            <Plus className="h-6 w-6" strokeWidth={2.25} />
          </button>
        )}
      </div>

      <MoreSheet
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        items={extraVisible}
        onPick={navigate}
      />

      <QuickSheet
        open={quickOpen}
        onClose={() => setQuickOpen(false)}
        onPick={navigate}
      />
    </ToastProvider>
  );
}

/* ═══════════════════ MORE SHEET ═══════════════════ */

function MoreSheet({
  open,
  onClose,
  items,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  items: ExtraNavItem[];
  onPick: (m: ModuleId) => void;
}) {
  return (
    <BottomSheet open={open} onClose={onClose} title="Modul">
      {items.length === 0 ? (
        <p className="py-6 text-center text-body text-fg-mid">
          Semua modul sedang nonaktif. Aktifkan di Pengaturan.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          {items.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onPick(item.id)}
                className="flex items-center gap-3 rounded-card border border-line bg-surface-2 px-3 py-3 text-left transition-colors duration-standard ease-standard hover:border-line-strong"
              >
                <Icon className="h-5 w-5 shrink-0 text-accent-500" strokeWidth={1.75} />
                <span className="text-label text-fg-hi">{MODULE_LABELS[item.id]}</span>
              </button>
            );
          })}
        </div>
      )}
    </BottomSheet>
  );
}

/* ═══════════════════ QUICK SHEET ═══════════════════ */

interface QuickAction {
  id: ModuleId;
  label: string;
  hint: string;
  icon: LucideIcon;
}

const QUICK_ACTIONS: QuickAction[] = [
  { id: 'keuangan', label: 'Transaksi', hint: 'Catat uang masuk atau keluar', icon: Wallet },
  { id: 'tugas', label: 'Tugas', hint: 'Tambahkan satu hal yang perlu dikerjakan', icon: CheckSquare },
  { id: 'catatan', label: 'Catatan', hint: 'Tulis ide atau rujukan', icon: FileText },
  { id: 'jurnal', label: 'Jurnal', hint: 'Refleksi hari ini', icon: BookOpen },
];

function QuickSheet({
  open,
  onClose,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (m: ModuleId) => void;
}) {
  return (
    <BottomSheet open={open} onClose={onClose} title="Aksi cepat">
      <div className="flex flex-col gap-2">
        {QUICK_ACTIONS.map((a) => {
          const Icon = a.icon;
          return (
            <button
              key={a.id}
              type="button"
              onClick={() => onPick(a.id)}
              className="flex items-start gap-3 rounded-card border border-line bg-surface-2 px-4 py-3 text-left transition-colors duration-standard ease-standard hover:border-line-strong"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-button bg-accent-50 text-accent-500">
                <Icon className="h-5 w-5" strokeWidth={1.75} />
              </div>
              <div className="min-w-0">
                <p className="text-label text-fg-hi">{a.label}</p>
                <p className="text-caption text-fg-lo">{a.hint}</p>
              </div>
            </button>
          );
        })}
      </div>
    </BottomSheet>
  );
}