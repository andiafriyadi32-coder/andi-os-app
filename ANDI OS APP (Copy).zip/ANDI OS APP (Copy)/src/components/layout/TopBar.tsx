import { Avatar } from '../ui/Avatar';
import { useAppState } from '../../lib/store';

export interface TopBarProps {
  onAvatar: () => void;
}

export function TopBar({ onAvatar }: TopBarProps) {
  const state = useAppState();
  return (
    <header className="safe-top sticky top-0 z-20 border-b border-line bg-surface-0/70 backdrop-blur-xl backdrop-saturate-150">
      <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between px-4 lg:px-8">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-button bg-deep-hero text-white lg:hidden">
            <span className="text-label font-bold">A</span>
          </div>
          <div className="min-w-0">
            <p className="truncate text-h2 text-fg-hi">Halo, {state.settings.nama}</p>
            <p className="text-caption text-fg-lo">Selamat berkegiatan hari ini.</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onAvatar}
          className="rounded-full transition-transform duration-instant ease-standard active:scale-95"
          aria-label="Buka pengaturan"
        >
          <Avatar name={state.settings.nama} size={36} />
        </button>
      </div>
    </header>
  );
}