import {
  CheckSquare, Home, MoreHorizontal, Repeat, Wallet, type LucideIcon,
} from 'lucide-react';

import { MODULE_LABELS, type ModuleId } from '../../lib/types';

interface NavItem {
  id: ModuleId;
  icon: LucideIcon;
}

const NAV_MAIN: NavItem[] = [
  { id: 'beranda', icon: Home },
  { id: 'keuangan', icon: Wallet },
  { id: 'tugas', icon: CheckSquare },
  { id: 'kebiasaan', icon: Repeat },
];

export interface BottomNavProps {
  module: ModuleId;
  onNavigate: (m: ModuleId) => void;
  onMore: () => void;
}

export function BottomNav({ module, onNavigate, onMore }: BottomNavProps) {
  const moreActive = !NAV_MAIN.some((i) => i.id === module);
  return (
    <nav className="safe-bottom fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface-0/85 backdrop-blur-xl backdrop-saturate-150 lg:hidden">
      <div className="mx-auto grid h-16 max-w-md grid-cols-5">
        {NAV_MAIN.map((item) => {
          const Icon = item.icon;
          const active = module === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center gap-1 transition-colors duration-standard ease-standard ${
                active ? 'text-accent-500' : 'text-fg-lo'
              }`}
              aria-label={MODULE_LABELS[item.id]}
            >
              <Icon className="h-5 w-5" strokeWidth={1.75} />
              <span className="text-[10px] font-medium">{MODULE_LABELS[item.id]}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={onMore}
          className={`flex flex-col items-center justify-center gap-1 transition-colors duration-standard ease-standard ${
            moreActive ? 'text-accent-500' : 'text-fg-lo'
          }`}
          aria-label="Menu lainnya"
        >
          <MoreHorizontal className="h-5 w-5" strokeWidth={1.75} />
          <span className="text-[10px] font-medium">Lainnya</span>
        </button>
      </div>
    </nav>
  );
}