import { useMemo, useState } from 'react';
import {
  ArrowRight, Plus, Trash2, Wallet as WalletIcon,
} from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import {
  EXPENSE_CATEGORY_OPTIONS, INCOME_CATEGORY_OPTIONS,
  type Budget, type SavingsGoal, type Transaction, type TxType, type Wallet,
} from '../../lib/types';
import {
  formatDateShort, formatRp, monthKey, todayStr, uid,
} from '../../lib/format';
import { parseQuickCapture } from '../../lib/parser';
import {
  cashflow, categoryBreakdown, safeDailyBudget, safeToSpendToday,
  totalBalance, walletBalance, zeroBasedBudget,
} from '../../lib/calc/finance';
import { Button } from '../../components/ui/Button';
import { Chip } from '../../components/ui/Chip';
import { Input } from '../../components/ui/Input';
import { SegmentedControl, type SegmentedOption } from '../../components/ui/SegmentedControl';
import { Select } from '../../components/ui/Select';
import { Textarea } from '../../components/ui/Textarea';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { RingProgress } from '../../components/ui/RingProgress';
import { StatCard } from '../../components/ui/StatCard';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { Modal } from '../../components/ui/Modal';
import { useToast } from '../../components/ui/Toast';

type Tab = 'ringkasan' | 'transaksi' | 'budget' | 'dompet' | 'target';

const TAB_OPTIONS: SegmentedOption<Tab>[] = [
  { value: 'ringkasan', label: 'Ringkasan' },
  { value: 'transaksi', label: 'Transaksi' },
  { value: 'budget', label: 'Anggaran' },
  { value: 'dompet', label: 'Dompet' },
  { value: 'target', label: 'Target' },
];

export default function Keuangan(): JSX.Element {
  const [tab, setTab] = useState<Tab>('ringkasan');

  return (
    <div className="flex flex-col gap-4">
      <header>
        <p className="text-micro uppercase text-fg-lo">Keuangan</p>
        <h1 className="text-h1 text-fg-hi">Arus kas, anggaran, target.</h1>
      </header>

      <div className="overflow-x-auto">
        <SegmentedControl options={TAB_OPTIONS} value={tab} onChange={setTab} />
      </div>

      {tab === 'ringkasan' && <RingkasanTab />}
      {tab === 'transaksi' && <TransaksiTab />}
      {tab === 'budget' && <BudgetTab />}
      {tab === 'dompet' && <DompetTab />}
      {tab === 'target' && <TargetTab />}
    </div>
  );
}

/* ═══════════════════ RINGKASAN ═══════════════════ */

function RingkasanTab() {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const today = new Date();
  const [quick, setQuick] = useState('');

  const total = useMemo(() => totalBalance(state.wallets, state.transactions), [state]);
  const mk = monthKey(today);
  const monthFlow = useMemo(
    () => cashflow(state.transactions, (t) => t.date.startsWith(mk)),
    [state.transactions, mk]
  );
  const breakdown = useMemo(
    () => categoryBreakdown(state.transactions, (t) => t.date.startsWith(mk)).slice(0, 6),
    [state.transactions, mk]
  );
  const safeBudget = useMemo(
    () => safeDailyBudget(state.transactions, today),
    [state.transactions]
  );
  const todayLeft = useMemo(
    () => safeToSpendToday(state.transactions, today),
    [state.transactions]
  );

  function handleQuickSubmit() {
    const parsed = parseQuickCapture(quick);
    if (!parsed) {
      show('Tidak bisa membaca nominal. Coba "bensin 20rb" atau "gaji 1.5jt".');
      return;
    }
    const wallet = state.wallets.find((w) => w.id === 'w-tunai') ?? state.wallets[0];
    const tx: Transaction = {
      id: uid(),
      type: parsed.type,
      amount: parsed.amount,
      category: parsed.category,
      wallet_id: wallet?.id ?? 'w-tunai',
      date: todayStr(),
      note: quick.trim(),
      created_at: new Date().toISOString(),
    };
    dispatch({ type: 'transaction:add', tx });
    setQuick('');
    show(`Tercatat: ${parsed.category} ${formatRp(parsed.amount)}`);
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <p className="text-micro uppercase text-fg-lo">Catat cepat</p>
        <div className="mt-2 flex flex-col gap-2 sm:flex-row">
          <div className="flex-1">
            <Input
              value={quick}
              onChange={(e) => setQuick(e.target.value)}
              placeholder='Contoh: "bensin 20rb", "gaji 1.5jt"'
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleQuickSubmit();
              }}
              aria-label="Catat transaksi cepat"
            />
          </div>
          <Button
            onClick={handleQuickSubmit}
            icon={<Plus className="h-4 w-4" strokeWidth={2} />}
          >
            Catat
          </Button>
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Card>
          <p className="text-micro uppercase text-fg-lo">Saldo total</p>
          <p className="num mt-1 text-hero-num text-fg-hi">{formatRp(total)}</p>
        </Card>
        <StatCard
          label="Pemasukan bulan ini"
          value={formatRp(monthFlow.income)}
          tone="success"
        />
        <StatCard
          label="Pengeluaran bulan ini"
          value={formatRp(monthFlow.expense)}
          tone="danger"
        />
      </div>

      <Card>
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="text-micro uppercase text-fg-lo">Batas aman jajan hari ini</p>
            <p
              className={`num mt-1 text-stat-num ${
                todayLeft < 0 ? 'text-danger' : 'text-fg-hi'
              }`}
            >
              {formatRp(Math.max(0, todayLeft))}
            </p>
            <p className="mt-1 text-caption text-fg-lo">
              {todayLeft < 0
                ? 'Kamu sudah lewat batas hari ini.'
                : `${safeBudget.sisaHari} hari tersisa · budget harian ${formatRp(safeBudget.budget)}`}
            </p>
          </div>
          <RingProgress
            value={
              safeBudget.budget > 0 ? Math.max(0, todayLeft / safeBudget.budget) : 0
            }
            size={64}
            tone={todayLeft < 0 ? 'danger' : 'accent'}
          />
        </div>
      </Card>

      <Card>
        <p className="mb-3 text-micro uppercase text-fg-lo">Breakdown kategori bulan ini</p>
        {breakdown.length === 0 ? (
          <p className="py-6 text-center text-caption text-fg-lo">
            Belum ada pengeluaran bulan ini.
          </p>
        ) : (
          <ul className="flex flex-col gap-3">
            {breakdown.map((b) => (
              <li key={b.category}>
                <div className="mb-1 flex items-center justify-between text-caption">
                  <span className="text-fg-hi">{b.category}</span>
                  <span className="num text-fg-lo">
                    {formatRp(b.total)} · {b.pct.toFixed(0)}%
                  </span>
                </div>
                <ProgressBar value={b.pct / 100} />
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

/* ═══════════════════ TRANSAKSI ═══════════════════ */

function TransaksiTab() {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [query, setQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | TxType>('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [deleting, setDeleting] = useState<Transaction | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...state.transactions]
      .filter((t) => (typeFilter === 'all' ? true : t.type === typeFilter))
      .filter((t) =>
        q ? t.note.toLowerCase().includes(q) || t.category.toLowerCase().includes(q) : true
      )
      .sort(
        (a, b) => b.date.localeCompare(a.date) || b.created_at.localeCompare(a.created_at)
      );
  }, [state.transactions, query, typeFilter]);

  const grouped = useMemo(() => {
    const map = new Map<string, Transaction[]>();
    for (const t of filtered) {
      const list = map.get(t.date) ?? [];
      list.push(t);
      map.set(t.date, list);
    }
    return Array.from(map.entries());
  }, [filtered]);

  function confirmDelete() {
    if (!deleting) return;
    const snapshot = deleting;
    dispatch({ type: 'transaction:delete', id: snapshot.id });
    setDeleting(null);
    show('Transaksi dihapus.', {
      action: {
        label: 'Urungkan',
        onClick: () => {
          dispatch({ type: 'transaction:add', tx: snapshot });
          show('Transaksi dikembalikan.');
        },
      },
      duration: 5000,
    });
  }

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }

  function openEdit(t: Transaction) {
    setEditing(t);
    setFormOpen(true);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <div className="flex-1">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari catatan atau kategori"
            aria-label="Cari transaksi"
          />
        </div>
        <Button onClick={openCreate} icon={<Plus className="h-4 w-4" strokeWidth={2} />}>
          Transaksi
        </Button>
      </div>

      <div className="flex flex-wrap gap-1.5">
        <Chip active={typeFilter === 'all'} onClick={() => setTypeFilter('all')}>
          Semua
        </Chip>
        <Chip active={typeFilter === 'expense'} onClick={() => setTypeFilter('expense')}>
          Pengeluaran
        </Chip>
        <Chip active={typeFilter === 'income'} onClick={() => setTypeFilter('income')}>
          Pemasukan
        </Chip>
        <Chip active={typeFilter === 'transfer'} onClick={() => setTypeFilter('transfer')}>
          Transfer
        </Chip>
        <Chip active={typeFilter === 'adjustment'} onClick={() => setTypeFilter('adjustment')}>
          Penyesuaian
        </Chip>
      </div>

      {grouped.length === 0 ? (
        <EmptyState
          icon={<WalletIcon className="h-10 w-10" strokeWidth={1.5} />}
          title="Belum ada transaksi."
          description="Catat pengeluaran pertamamu untuk melihat arus kas."
          action={
            <Button onClick={openCreate} icon={<Plus className="h-4 w-4" strokeWidth={2} />}>
              Transaksi baru
            </Button>
          }
        />
      ) : (
        <div className="flex flex-col gap-4">
          {grouped.map(([date, items]) => {
            const dayTotal = items.reduce(
              (s, t) =>
                s + (t.type === 'expense' ? -t.amount : t.type === 'income' ? t.amount : 0),
              0
            );
            return (
              <Card key={date} padded={false}>
                <div className="flex items-center justify-between border-b border-line-subtle px-4 py-2">
                  <p className="text-label text-fg-mid">{formatDateShort(new Date(date))}</p>
                  <p
                    className={`num text-caption ${
                      dayTotal >= 0 ? 'text-success' : 'text-danger'
                    }`}
                  >
                    {dayTotal >= 0 ? '+' : ''}
                    {formatRp(dayTotal)}
                  </p>
                </div>
                <ul className="divide-y divide-line-subtle">
                  {items.map((t) => (
                    <li key={t.id} className="flex items-center gap-2 px-4 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-body text-fg-hi">
                          {t.note || t.category}
                        </p>
                        <p className="text-caption text-fg-lo">
                          {t.category} ·{' '}
                          {state.wallets.find((w) => w.id === t.wallet_id)?.name ?? '—'}
                        </p>
                      </div>
                      <p
                        className={`num text-body font-semibold ${
                          t.type === 'expense'
                            ? 'text-danger'
                            : t.type === 'income'
                              ? 'text-success'
                              : 'text-fg-mid'
                        }`}
                      >
                        {t.type === 'expense' ? '-' : t.type === 'income' ? '+' : ''}
                        {formatRp(t.amount)}
                      </p>
                      <button
                        type="button"
                        onClick={() => openEdit(t)}
                        className="rounded-button p-1.5 text-fg-lo hover:bg-surface-3 hover:text-fg-hi"
                        aria-label="Ubah"
                      >
                        <ArrowRight className="h-4 w-4" strokeWidth={1.75} />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleting(t)}
                        className="rounded-button p-1.5 text-fg-lo hover:bg-surface-3 hover:text-danger"
                        aria-label="Hapus"
                      >
                        <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                      </button>
                    </li>
                  ))}
                </ul>
              </Card>
            );
          })}
        </div>
      )}

      <TransactionForm
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditing(null);
        }}
        initial={editing}
        wallets={state.wallets}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus transaksi ini?"
        description={
          deleting ? `"${deleting.note || deleting.category}" akan dihapus.` : ''
        }
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

function TransactionForm({
  open,
  onClose,
  initial,
  wallets,
}: {
  open: boolean;
  onClose: () => void;
  initial: Transaction | null;
  wallets: Wallet[];
}) {
  const dispatch = useDispatch();
  const { show } = useToast();
  const [type, setType] = useState<TxType>(initial?.type ?? 'expense');
  const [amount, setAmount] = useState(initial ? String(initial.amount) : '');
  const [category, setCategory] = useState(initial?.category ?? 'Makan');
  const [walletId, setWalletId] = useState(initial?.wallet_id ?? wallets[0]?.id ?? '');
  const [toWalletId, setToWalletId] = useState(
    initial?.to_wallet_id ?? wallets[1]?.id ?? ''
  );
  const [sign, setSign] = useState<'+' | '-'>(initial?.sign ?? '-');
  const [date, setDate] = useState(initial?.date ?? todayStr());
  const [note, setNote] = useState(initial?.note ?? '');
  const [error, setError] = useState<string | null>(null);

  function submit() {
    const amt = parseInt(amount, 10);
    if (!Number.isFinite(amt) || amt <= 0) {
      setError('Nominal harus lebih dari nol.');
      return;
    }
    if (type === 'transfer' && walletId === toWalletId) {
      setError('Dompet asal dan tujuan harus berbeda.');
      return;
    }
    const payload: Transaction = {
      id: initial?.id ?? uid(),
      type,
      amount: amt,
      category: type === 'transfer' ? 'Transfer' : category,
      wallet_id: walletId,
      to_wallet_id: type === 'transfer' ? toWalletId : undefined,
      sign: type === 'adjustment' ? sign : undefined,
      date,
      note,
      created_at: initial?.created_at ?? new Date().toISOString(),
    };
    if (initial) {
      dispatch({ type: 'transaction:update', id: initial.id, patch: payload });
      show('Transaksi diperbarui.');
    } else {
      dispatch({ type: 'transaction:add', tx: payload });
      show('Transaksi tercatat.');
    }
    setError(null);
    onClose();
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initial ? 'Ubah transaksi' : 'Transaksi baru'}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>
            Batal
          </Button>
          <Button onClick={submit}>{initial ? 'Simpan' : 'Catat'}</Button>
        </div>
      }
    >
      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap gap-1.5">
          <Chip active={type === 'expense'} onClick={() => setType('expense')}>
            Pengeluaran
          </Chip>
          <Chip active={type === 'income'} onClick={() => setType('income')}>
            Pemasukan
          </Chip>
          <Chip active={type === 'transfer'} onClick={() => setType('transfer')}>
            Transfer
          </Chip>
          <Chip active={type === 'adjustment'} onClick={() => setType('adjustment')}>
            Penyesuaian
          </Chip>
        </div>

        <Input
          label="Nominal (Rp)"
          type="number"
          inputMode="numeric"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          error={error ?? undefined}
        />

        {(type === 'expense' || type === 'income') && (
          <Select
            label="Kategori"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {(type === 'expense' ? EXPENSE_CATEGORY_OPTIONS : INCOME_CATEGORY_OPTIONS).map(
              (c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              )
            )}
          </Select>
        )}

        {type === 'transfer' ? (
          <>
            <Select
              label="Dari"
              value={walletId}
              onChange={(e) => setWalletId(e.target.value)}
            >
              {wallets.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </Select>
            <Select
              label="Ke"
              value={toWalletId}
              onChange={(e) => setToWalletId(e.target.value)}
            >
              {wallets.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </Select>
          </>
        ) : (
          <Select
            label="Dompet"
            value={walletId}
            onChange={(e) => setWalletId(e.target.value)}
          >
            {wallets.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </Select>
        )}

        {type === 'adjustment' && (
          <div className="flex gap-2">
            <Chip active={sign === '+'} onClick={() => setSign('+')}>
              Tambah saldo
            </Chip>
            <Chip active={sign === '-'} onClick={() => setSign('-')}>
              Kurangi saldo
            </Chip>
          </div>
        )}

        <Input
          label="Tanggal"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <Textarea
          label="Catatan"
          rows={2}
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
    </Modal>
  );
}

/* ═══════════════════ BUDGET ═══════════════════ */

function BudgetTab() {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState(EXPENSE_CATEGORY_OPTIONS[0] ?? 'Makan');
  const [amount, setAmount] = useState('');

  const mk = monthKey(new Date());
  const result = useMemo(
    () => zeroBasedBudget(state.transactions, state.budgets, mk),
    [state.transactions, state.budgets, mk]
  );

  function submit() {
    const amt = parseInt(amount, 10);
    if (!Number.isFinite(amt) || amt <= 0) {
      show('Nominal anggaran harus lebih dari nol.');
      return;
    }
    const existing = state.budgets.find(
      (b) => b.category === category && b.period === 'monthly'
    );
    if (existing) {
      dispatch({ type: 'budget:update', id: existing.id, patch: { amount: amt } });
    } else {
      const newBudget: Budget = {
        id: uid(),
        category,
        amount: amt,
        period: 'monthly',
      };
      dispatch({ type: 'budget:add', budget: newBudget });
    }
    setAmount('');
    setOpen(false);
    show('Anggaran tersimpan.');
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <p className="text-micro uppercase text-fg-lo">Belum dialokasikan</p>
        <p
          className={`num mt-1 text-stat-num ${
            result.toBeBudgeted < 0 ? 'text-danger' : 'text-fg-hi'
          }`}
        >
          {formatRp(result.toBeBudgeted)}
        </p>
        <p className="mt-1 text-caption text-fg-lo">
          {result.toBeBudgeted < 0
            ? 'Anggaran melebihi pemasukan bulan ini.'
            : 'Sisa pemasukan yang belum punya amplop.'}
        </p>
        <div className="mt-3">
          <Button
            onClick={() => setOpen(true)}
            icon={<Plus className="h-4 w-4" strokeWidth={2} />}
          >
            Atur anggaran
          </Button>
        </div>
      </Card>

      {result.items.length === 0 ? (
        <EmptyState
          icon={<WalletIcon className="h-10 w-10" strokeWidth={1.5} />}
          title="Belum ada anggaran."
          description="Buat amplop per kategori untuk mengontrol pengeluaran."
          action={
            <Button
              onClick={() => setOpen(true)}
              icon={<Plus className="h-4 w-4" strokeWidth={2} />}
            >
              Atur anggaran
            </Button>
          }
        />
      ) : (
        <div className="flex flex-col gap-2">
          {result.items.map((item) => (
            <Card key={item.budget.id} padded={false}>
              <div className="p-4">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <p className="text-label text-fg-hi">{item.budget.category}</p>
                  <p className="num text-caption text-fg-lo">
                    {formatRp(item.spent)} / {formatRp(item.budget.amount)}
                  </p>
                </div>
                <ProgressBar
                  value={Math.min(1, item.progress)}
                  tone={
                    item.overspent ? 'danger' : item.progress > 0.8 ? 'warning' : 'accent'
                  }
                />
                <div className="mt-2 flex items-center justify-between">
                  <p
                    className={`text-caption ${
                      item.overspent ? 'text-danger' : 'text-fg-lo'
                    }`}
                  >
                    {item.overspent
                      ? `Lewat ${formatRp(Math.abs(item.remaining))}`
                      : `Sisa ${formatRp(item.remaining)}`}
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      const next = window.prompt(
                        `Anggaran ${item.budget.category} (Rp)`,
                        String(item.budget.amount)
                      );
                      if (!next) return;
                      const amt = parseInt(next, 10);
                      if (!Number.isFinite(amt) || amt <= 0) return;
                      dispatch({
                        type: 'budget:update',
                        id: item.budget.id,
                        patch: { amount: amt },
                      });
                      show('Anggaran diperbarui.');
                    }}
                    className="text-caption text-accent-500 hover:underline"
                  >
                    Ubah
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Atur anggaran"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Batal
            </Button>
            <Button onClick={submit}>Simpan</Button>
          </div>
        }
      >
        <div className="flex flex-col gap-3">
          <Select
            label="Kategori"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {EXPENSE_CATEGORY_OPTIONS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </Select>
          <Input
            label="Anggaran (Rp)"
            type="number"
            inputMode="numeric"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>
      </Modal>
    </div>
  );
}

/* ═══════════════════ DOMPET ═══════════════════ */

function DompetTab() {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [editing, setEditing] = useState<Wallet | null>(null);
  const [editName, setEditName] = useState('');
  const [editInitial, setEditInitial] = useState('');

  function openEdit(w: Wallet) {
    setEditing(w);
    setEditName(w.name);
    setEditInitial(String(w.initial_balance));
  }

  function submitEdit() {
    if (!editing) return;
    const init = parseInt(editInitial, 10);
    dispatch({
      type: 'wallet:update',
      id: editing.id,
      patch: {
        name: editName.trim() || editing.name,
        initial_balance: Number.isFinite(init) ? init : 0,
      },
    });
    show('Dompet diperbarui.');
    setEditing(null);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {state.wallets.map((w) => {
          const bal = walletBalance(w, state.transactions);
          return (
            <Card key={w.id}>
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-button bg-accent-50 text-accent-500">
                  <WalletIcon className="h-4 w-4" strokeWidth={1.75} />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-h2 text-fg-hi">{w.name}</p>
                  <p className="text-caption text-fg-lo capitalize">{w.type}</p>
                </div>
              </div>
              <p
                className={`num mt-3 text-stat-num ${
                  bal < 0 ? 'text-danger' : 'text-fg-hi'
                }`}
              >
                {formatRp(bal)}
              </p>
              <p className="mt-1 text-caption text-fg-lo">
                Saldo awal {formatRp(w.initial_balance)}
              </p>
              <button
                type="button"
                onClick={() => openEdit(w)}
                className="mt-3 text-caption text-accent-500 hover:underline"
              >
                Ubah
              </button>
            </Card>
          );
        })}
      </div>

      <Modal
        open={editing !== null}
        onClose={() => setEditing(null)}
        title="Ubah dompet"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setEditing(null)}>
              Batal
            </Button>
            <Button onClick={submitEdit}>Simpan</Button>
          </div>
        }
      >
        <div className="flex flex-col gap-3">
          <Input
            label="Nama"
            value={editName}
            onChange={(e) => setEditName(e.target.value)}
          />
          <Input
            label="Saldo awal (Rp)"
            type="number"
            inputMode="numeric"
            value={editInitial}
            onChange={(e) => setEditInitial(e.target.value)}
          />
        </div>
      </Modal>
    </div>
  );
}

/* ═══════════════════ TARGET ═══════════════════ */

function TargetTab() {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [target, setTarget] = useState('');
  const [deadline, setDeadline] = useState('');
  const [deleting, setDeleting] = useState<SavingsGoal | null>(null);

  function submit() {
    const t = parseInt(target, 10);
    if (!name.trim() || !Number.isFinite(t) || t <= 0) {
      show('Nama dan nominal target harus valid.');
      return;
    }
    const goal: SavingsGoal = {
      id: uid(),
      name: name.trim(),
      target_amount: t,
      current_amount: 0,
      deadline: deadline || undefined,
      created_at: new Date().toISOString(),
    };
    dispatch({ type: 'goal:add', goal });
    setName('');
    setTarget('');
    setDeadline('');
    setOpen(false);
    show('Target ditambahkan.');
  }

  function addFunds(goal: SavingsGoal) {
    const raw = window.prompt(`Tambah dana ke "${goal.name}" (Rp)`, '');
    if (!raw) return;
    const amt = parseInt(raw, 10);
    if (!Number.isFinite(amt) || amt <= 0) return;
    dispatch({
      type: 'goal:update',
      id: goal.id,
      patch: { current_amount: goal.current_amount + amt },
    });
    show(`Ditambah ${formatRp(amt)} ke ${goal.name}.`);
  }

  function confirmDelete() {
    if (!deleting) return;
    const snapshot = deleting;
    dispatch({ type: 'goal:delete', id: snapshot.id });
    setDeleting(null);
    show('Target dihapus.', {
      action: {
        label: 'Urungkan',
        onClick: () => dispatch({ type: 'goal:add', goal: snapshot }),
      },
      duration: 5000,
    });
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-end">
        <Button
          onClick={() => setOpen(true)}
          icon={<Plus className="h-4 w-4" strokeWidth={2} />}
        >
          Target baru
        </Button>
      </div>

      {state.savings_goals.length === 0 ? (
        <EmptyState
          icon={<WalletIcon className="h-10 w-10" strokeWidth={1.5} />}
          title="Belum ada target tabungan."
          description="Apa yang mau kamu kejar? Mulai dari satu target kecil."
          action={<Button onClick={() => setOpen(true)}>Target baru</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {state.savings_goals.map((g) => {
            const pct = g.target_amount > 0 ? g.current_amount / g.target_amount : 0;
            return (
              <Card key={g.id}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-h2 text-fg-hi">{g.name}</p>
                    <p className="num mt-1 text-caption text-fg-lo">
                      {formatRp(g.current_amount)} / {formatRp(g.target_amount)}
                    </p>
                    {g.deadline && (
                      <p className="text-caption text-fg-lo">
                        Tenggat {formatDateShort(new Date(g.deadline))}
                      </p>
                    )}
                  </div>
                  <RingProgress value={pct} size={56}>
                    <span className="num text-[10px] text-fg-hi">
                      {Math.round(pct * 100)}%
                    </span>
                  </RingProgress>
                </div>
                <div className="mt-3 flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => addFunds(g)}>
                    Tambah dana
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setDeleting(g)}>
                    Hapus
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Target baru"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Batal
            </Button>
            <Button onClick={submit}>Simpan</Button>
          </div>
        }
      >
        <div className="flex flex-col gap-3">
          <Input
            label="Nama target"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <Input
            label="Nominal target (Rp)"
            type="number"
            inputMode="numeric"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
          />
          <Input
            label="Tenggat (opsional)"
            type="date"
            value={deadline}
            onChange={(e) => setDeadline(e.target.value)}
          />
        </div>
      </Modal>

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus target ini?"
        description={deleting ? `"${deleting.name}" akan dihapus.` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}