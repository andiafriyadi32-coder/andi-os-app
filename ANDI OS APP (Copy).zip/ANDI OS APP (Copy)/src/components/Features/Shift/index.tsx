import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import type { Shift, ShiftType } from '../../lib/types';
import { formatDateFull, formatDateShort, toDateStr, todayStr, uid } from '../../lib/format';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Textarea } from '../../components/ui/Textarea';
import { Card } from '../../components/ui/Card';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { useToast } from '../../components/ui/Toast';

const SHIFT_TYPES: { value: ShiftType; label: string; bg: string; text: string }[] = [
  { value: 'pagi', label: 'Pagi', bg: 'bg-warning/20', text: 'text-warning' },
  { value: 'siang', label: 'Siang', bg: 'bg-info/20', text: 'text-info' },
  { value: 'malam', label: 'Malam', bg: 'bg-accent-500/20', text: 'text-accent-500' },
  { value: 'libur', label: 'Libur', bg: 'bg-surface-4', text: 'text-fg-mid' },
  { value: 'off', label: 'Off', bg: 'bg-surface-3', text: 'text-fg-lo' },
];

function shiftStyle(type: ShiftType) {
  return SHIFT_TYPES.find((s) => s.value === type) ?? SHIFT_TYPES[4];
}

export default function Shift(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();

  const now = new Date();
  const [viewMonth, setViewMonth] = useState(new Date(now.getFullYear(), now.getMonth(), 1));
  const [editingDate, setEditingDate] = useState<string | null>(null);

  const shiftsByDate = useMemo(() => {
    const map = new Map<string, Shift>();
    for (const s of state.shifts) map.set(s.date, s);
    return map;
  }, [state.shifts]);

  const days = useMemo(() => buildMonthGrid(viewMonth), [viewMonth]);

  const nextShift = useMemo(() => {
    const t = todayStr();
    const upcoming = state.shifts
      .filter((s) => s.date >= t && s.shift_type !== 'libur' && s.shift_type !== 'off')
      .sort((a, b) => a.date.localeCompare(b.date));
    return upcoming[0] ?? null;
  }, [state.shifts]);

  function prevMonth() {
    setViewMonth((d) => new Date(d.getFullYear(), d.getMonth() - 1, 1));
  }
  function nextMonth() {
    setViewMonth((d) => new Date(d.getFullYear(), d.getMonth() + 1, 1));
  }

  function setShift(date: string, type: ShiftType) {
    const existing = shiftsByDate.get(date);
    if (existing) {
      if (type === existing.shift_type) {
        dispatch({ type: 'shift:delete', id: existing.id });
        show('Shift dihapus.');
      } else {
        dispatch({ type: 'shift:update', id: existing.id, patch: { shift_type: type } });
        show(`Diubah ke ${labelFor(type)}.`);
      }
    } else {
      dispatch({
        type: 'shift:add',
        shift: { id: uid(), date, shift_type: type },
      });
      show(`${labelFor(type)} ditandai.`);
    }
    setEditingDate(null);
  }

  const editShift = editingDate ? shiftsByDate.get(editingDate) ?? null : null;

  return (
    <div className="flex flex-col gap-4">
      <header>
        <p className="text-micro uppercase text-fg-lo">Shift</p>
        <h1 className="text-h1 text-fg-hi">Jadwal kerja dan hitungan menuju shift.</h1>
      </header>

      {nextShift && (
        <Card>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-button bg-accent-50 text-accent-500">
              <Clock className="h-5 w-5" strokeWidth={1.75} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-micro uppercase text-fg-lo">Shift berikutnya</p>
              <p className="truncate text-h2 text-fg-hi">
                {labelFor(nextShift.shift_type)} · {formatDateShort(new Date(nextShift.date))}
              </p>
              <p className="text-caption text-fg-lo">{countdown(nextShift)}</p>
            </div>
          </div>
        </Card>
      )}

      <Card padded={false}>
        <div className="flex items-center justify-between border-b border-line px-3 py-2">
          <button
            type="button"
            onClick={prevMonth}
            className="rounded-button p-1.5 text-fg-mid hover:bg-surface-3 hover:text-fg-hi"
            aria-label="Bulan sebelumnya"
          >
            <ChevronLeft className="h-5 w-5" strokeWidth={1.75} />
          </button>
          <p className="text-label text-fg-hi">
            {monthLabel(viewMonth)}
          </p>
          <button
            type="button"
            onClick={nextMonth}
            className="rounded-button p-1.5 text-fg-mid hover:bg-surface-3 hover:text-fg-hi"
            aria-label="Bulan berikutnya"
          >
            <ChevronRight className="h-5 w-5" strokeWidth={1.75} />
          </button>
        </div>

        <div className="grid grid-cols-7 border-b border-line-subtle bg-surface-3/50">
          {['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'].map((d) => (
            <div key={d} className="py-1.5 text-center text-[10px] font-semibold uppercase tracking-wide text-fg-lo">
              {d}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-px bg-line-subtle">
          {days.map((d, i) => {
            if (!d.date) {
              return <div key={`empty-${i}`} className="min-h-[52px] bg-surface-2" />;
            }
            const shift = shiftsByDate.get(d.date);
            const isToday = d.date === todayStr();
            const st = shift ? shiftStyle(shift.shift_type) : null;
            return (
              <button
                key={d.date}
                type="button"
                onClick={() => setEditingDate(d.date)}
                className={`flex min-h-[52px] flex-col items-center justify-center gap-0.5 bg-surface-2 text-caption transition-colors hover:bg-surface-3 ${
                  isToday ? 'ring-1 ring-inset ring-accent-500' : ''
                }`}
              >
                <span className={isToday ? 'font-bold text-accent-500' : 'text-fg-mid'}>
                  {d.day}
                </span>
                {shift && st && (
                  <span className={`rounded-chip px-1.5 py-0.5 text-[9px] font-semibold uppercase ${st.bg} ${st.text}`}>
                    {st.label}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </Card>

      <p className="text-center text-caption text-fg-dim">
        Ketuk tanggal untuk menandai shift.
      </p>

      <ShiftEditSheet
        date={editingDate}
        current={editShift}
        onClose={() => setEditingDate(null)}
        onPick={(type) => editingDate && setShift(editingDate, type)}
        onSaveMeta={(patch) => {
          if (!editShift) return;
          dispatch({ type: 'shift:update', id: editShift.id, patch });
          show('Shift diperbarui.');
          setEditingDate(null);
        }}
      />
    </div>
  );
}

function labelFor(type: ShiftType): string {
  return SHIFT_TYPES.find((s) => s.value === type)?.label ?? 'Off';
}

function buildMonthGrid(month: Date): { date: string | null; day: number }[] {
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const last = new Date(month.getFullYear(), month.getMonth() + 1, 0);
  const startOffset = (first.getDay() + 6) % 7; // Monday-first
  const out: { date: string | null; day: number }[] = [];
  for (let i = 0; i < startOffset; i++) out.push({ date: null, day: 0 });
  for (let d = 1; d <= last.getDate(); d++) {
    out.push({ date: toDateStr(new Date(month.getFullYear(), month.getMonth(), d)), day: d });
  }
  return out;
}

function monthLabel(d: Date): string {
  const names = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  return `${names[d.getMonth()]} ${d.getFullYear()}`;
}

function countdown(s: Shift): string {
  const now = new Date();
  const shiftDate = new Date(s.date);
  if (s.start_time) {
    const [h, m] = s.start_time.split(':').map(Number);
    shiftDate.setHours(h ?? 0, m ?? 0, 0, 0);
  }
  const diffMs = shiftDate.getTime() - now.getTime();
  if (diffMs < 0) return 'Sedang berjalan atau sudah lewat.';
  const days = Math.floor(diffMs / 86400000);
  const hours = Math.floor((diffMs % 86400000) / 3600000);
  if (days === 0 && hours === 0) return 'Kurang dari 1 jam lagi.';
  if (days === 0) return `${hours} jam lagi.`;
  return `${days} hari ${hours} jam lagi.`;
}

function ShiftEditSheet({
  date, current, onClose, onPick, onSaveMeta,
}: {
  date: string | null;
  current: Shift | null;
  onClose: () => void;
  onPick: (t: ShiftType) => void;
  onSaveMeta: (patch: Partial<Shift>) => void;
}) {
  const [startTime, setStartTime] = useState(current?.start_time ?? '');
  const [endTime, setEndTime] = useState(current?.end_time ?? '');
  const [notes, setNotes] = useState(current?.notes ?? '');

  if (!date) {
    return <BottomSheet open={false} onClose={onClose}>{null}</BottomSheet>;
  }

  return (
    <BottomSheet open onClose={onClose} title={formatDateFull(new Date(date))}>
      <div className="flex flex-col gap-4">
        <div>
          <p className="mb-2 text-micro uppercase text-fg-lo">Jenis shift</p>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {SHIFT_TYPES.map((t) => {
              const active = current?.shift_type === t.value;
              return (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => onPick(t.value)}
                  className={`flex items-center justify-center rounded-card border px-3 py-2.5 text-label transition-colors ${
                    active
                      ? 'border-accent-500 bg-accent-500 text-white'
                      : 'border-line bg-surface-2 text-fg-mid hover:border-line-strong'
                  }`}
                >
                  {t.label}
                </button>
              );
            })}
          </div>
        </div>

        {current && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <Input
                label="Mulai"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
              <Input
                label="Selesai"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
            <Textarea
              label="Catatan"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
            <Button
              onClick={() =>
                onSaveMeta({
                  start_time: startTime || undefined,
                  end_time: endTime || undefined,
                  notes: notes || undefined,
                })
              }
            >
              Simpan detail
            </Button>
          </>
        )}
      </div>
    </BottomSheet>
  );
}