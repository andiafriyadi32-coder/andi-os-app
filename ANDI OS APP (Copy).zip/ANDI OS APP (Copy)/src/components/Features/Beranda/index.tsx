import { useMemo } from 'react';
import {
  ArrowDownLeft, ArrowRight, ArrowUpRight, CheckSquare, Sparkles,
} from 'lucide-react';

import { useAppState } from '../../lib/store';
import { formatDateFull, formatRp, toDateStr, todayStr } from '../../lib/format';
import {
  safeDailyBudget, safeToSpendToday, totalBalance,
} from '../../lib/calc/finance';
import { habitsDoneToday, habitStreak } from '../../lib/calc/habit';
import type { Task, Transaction, Wallet } from '../../lib/types';
import { BentoCell, BentoGrid } from '../../components/ui/BentoGrid';
import { Card } from '../../components/ui/Card';
import { RingProgress } from '../../components/ui/RingProgress';
import { StatCard } from '../../components/ui/StatCard';
import { Heatmap } from '../../components/charts/Heatmap';

export default function Beranda(): JSX.Element {
  const state = useAppState();
  const today = new Date();

  const saldo = useMemo(
    () => totalBalance(state.wallets, state.transactions),
    [state.wallets, state.transactions]
  );

  const activeTasks = useMemo(
    () => state.tasks.filter((t) => t.status === 'todo'),
    [state.tasks]
  );

  const habitsDone = useMemo(
    () => habitsDoneToday(state.habits, state.habit_logs, today),
    [state.habits, state.habit_logs]
  );

  const safeBudget = useMemo(
    () => safeDailyBudget(state.transactions, today),
    [state.transactions]
  );

  const todayLeft = useMemo(
    () => safeToSpendToday(state.transactions, today),
    [state.transactions]
  );

  const recentTx = useMemo(
    () =>
      [...state.transactions]
        .sort((a, b) => b.created_at.localeCompare(a.created_at))
        .slice(0, 5),
    [state.transactions]
  );

  const urgentTasks = useMemo(() => {
    const tStr = todayStr();
    return [...state.tasks]
      .filter((t) => t.status === 'todo')
      .filter((t) => t.priority === 'high' || (t.due_date && t.due_date <= tStr))
      .sort((a, b) => {
        const rank = (p: Task['priority']) => (p === 'high' ? 0 : p === 'medium' ? 1 : 2);
        const r = rank(a.priority) - rank(b.priority);
        if (r !== 0) return r;
        return (a.due_date ?? '9999').localeCompare(b.due_date ?? '9999');
      })
      .slice(0, 5);
  }, [state.tasks]);

  const heatmapDays = useMemo(() => {
    const out: { date: string; value: number }[] = [];
    const habitIds = new Set(state.habits.map((h) => h.id));
    const logByDay = new Map<string, number>();
    for (const log of state.habit_logs) {
      if (!habitIds.has(log.habit_id)) continue;
      logByDay.set(log.date, (logByDay.get(log.date) ?? 0) + 1);
    }
    const cursor = new Date(today);
    for (let i = 27; i >= 0; i--) {
      const d = new Date(cursor);
      d.setDate(d.getDate() - i);
      const ds = toDateStr(d);
      out.push({ date: ds, value: logByDay.get(ds) ?? 0 });
    }
    return out;
  }, [state.habits, state.habit_logs]);

  const bestStreakHabit = useMemo(() => {
    if (state.habits.length === 0) return null;
    let best: { name: string; streak: number } | null = null;
    for (const h of state.habits) {
      const s = habitStreak(state.habit_logs, h.id, today);
      if (!best || s.current > best.streak) {
        best = { name: h.name, streak: s.current };
      }
    }
    return best;
  }, [state.habits, state.habit_logs]);

  const hour = today.getHours();
  const greeting =
    hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 18 ? 'Selamat sore' : 'Selamat malam';

  const habitRatio = state.habits.length > 0 ? habitsDone / state.habits.length : 0;

  return (
    <div className="flex flex-col gap-4">
      <header className="flex flex-col gap-1">
        <p className="text-micro uppercase text-fg-lo">{formatDateFull(today)}</p>
        <h1 className="text-display text-fg-hi">
          {greeting}, {state.settings.nama}.
        </h1>
      </header>

      <BentoGrid>
        <BentoCell span="xl">
          <HeroCell
            safeBudget={safeBudget.budget}
            todayLeft={todayLeft}
            activeTaskCount={activeTasks.length}
            habitsDone={habitsDone}
            habitsTotal={state.habits.length}
          />
        </BentoCell>

        <BentoCell>
          <StatCard
            label="Saldo Total"
            value={formatRp(saldo)}
            hint={`${state.wallets.length} dompet`}
            tone={saldo < 0 ? 'danger' : 'default'}
          />
        </BentoCell>

        <BentoCell>
          <StatCard
            label="Tugas Aktif"
            value={activeTasks.length}
            hint={urgentTasks.length > 0 ? `${urgentTasks.length} mendesak` : 'Tidak ada yang mendesak'}
            tone={urgentTasks.length > 0 ? 'warning' : 'default'}
          />
        </BentoCell>

        <BentoCell span="lg">
          <Card>
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0 flex-1">
                <p className="text-micro uppercase text-fg-lo">Batas aman jajan hari ini</p>
                <p
                  className={`num mt-1 text-stat-num ${
                    todayLeft < 0 ? 'text-danger' : 'text-fg-hi'
                  }`}
                >
                  {formatRp(Math.max(0, todayLeft))}
                </p>
                <p className="mt-1 text-caption text-fg-lo">
                  {todayLeft < 0
                    ? 'Kamu sudah lewat batas hari ini.'
                    : `${safeBudget.sisaHari} hari tersisa bulan ini.`}
                </p>
              </div>
              <div className="shrink-0">
                <RingProgress
                  value={safeBudget.budget > 0 ? Math.max(0, todayLeft / safeBudget.budget) : 0}
                  size={64}
                  tone={todayLeft < 0 ? 'danger' : 'accent'}
                >
                  <Sparkles className="h-5 w-5 text-accent-500" strokeWidth={1.75} />
                </RingProgress>
              </div>
            </div>
          </Card>
        </BentoCell>

        <BentoCell span="lg">
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-micro uppercase text-fg-lo">Kebiasaan hari ini</p>
              <p className="text-caption text-fg-lo">
                <span className="num text-fg-hi">{habitsDone}</span> / {state.habits.length}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <RingProgress value={habitRatio} size={72}>
                <span className="num text-label text-fg-hi">
                  {Math.round(habitRatio * 100)}%
                </span>
              </RingProgress>
              <div className="min-w-0 flex-1">
                {bestStreakHabit && bestStreakHabit.streak >= 2 ? (
                  <p className="text-body text-fg-mid">
                    <span className="text-fg-hi font-semibold">{bestStreakHabit.name}</span>{' '}
                    · streak {bestStreakHabit.streak} hari
                  </p>
                ) : (
                  <p className="text-body text-fg-mid">
                    Selesaikan satu kebiasaan untuk memulai streak.
                  </p>
                )}
              </div>
            </div>
          </Card>
        </BentoCell>

        <BentoCell span="lg">
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-micro uppercase text-fg-lo">Transaksi terakhir</p>
              <span className="text-caption text-fg-lo">{recentTx.length} dari 5</span>
            </div>
            {recentTx.length === 0 ? (
              <p className="py-6 text-center text-caption text-fg-lo">
                Belum ada transaksi. Catat pengeluaran pertamamu.
              </p>
            ) : (
              <ul className="flex flex-col divide-y divide-line-subtle">
                {recentTx.map((tx) => (
                  <TransactionRow key={tx.id} tx={tx} wallets={state.wallets} />
                ))}
              </ul>
            )}
          </Card>
        </BentoCell>

        <BentoCell span="lg">
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-micro uppercase text-fg-lo">Tugas mendesak</p>
              <ArrowRight className="h-4 w-4 text-fg-lo" strokeWidth={1.75} />
            </div>
            {urgentTasks.length === 0 ? (
              <p className="py-6 text-center text-caption text-fg-lo">
                Tidak ada yang mendesak hari ini. Kerja bagus.
              </p>
            ) : (
              <ul className="flex flex-col gap-2">
                {urgentTasks.map((t) => (
                  <li
                    key={t.id}
                    className="flex items-start gap-2 rounded-card-sm border border-line bg-surface-2 px-3 py-2"
                  >
                    <CheckSquare className="mt-0.5 h-4 w-4 shrink-0 text-accent-500" strokeWidth={1.75} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-body text-fg-hi">{t.title}</p>
                      <p className="text-caption text-fg-lo">
                        {t.due_date ? `Tenggat ${t.due_date}` : 'Tanpa tenggat'}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 rounded-chip px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                        t.priority === 'high'
                          ? 'bg-danger/15 text-danger'
                          : t.priority === 'medium'
                            ? 'bg-warning/15 text-warning'
                            : 'bg-surface-4 text-fg-mid'
                      }`}
                    >
                      {t.priority}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </BentoCell>

        <BentoCell span="lg">
          <Card>
            <p className="mb-3 text-micro uppercase text-fg-lo">Ritme 28 hari</p>
            <div className="overflow-x-auto pb-1">
              <Heatmap
                days={heatmapDays}
                weeks={4}
                maxValue={Math.max(1, state.habits.length)}
                cellSize={14}
              />
            </div>
          </Card>
        </BentoCell>
      </BentoGrid>
    </div>
  );
}

function HeroCell({
  safeBudget,
  todayLeft,
  activeTaskCount,
  habitsDone,
  habitsTotal,
}: {
  safeBudget: number;
  todayLeft: number;
  activeTaskCount: number;
  habitsDone: number;
  habitsTotal: number;
}) {
  return (
    <div className="relative overflow-hidden rounded-hero bg-deep-hero p-6">
      <div className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full bg-accent-300/20 blur-3xl" />
      <p className="text-micro uppercase text-white/50">Ringkasan hari ini</p>
      <div className="mt-3 grid grid-cols-3 gap-3">
        <HeroStat
          label="Aman jajan"
          value={formatRp(Math.max(0, todayLeft))}
          sub={`dari ${formatRp(Math.max(0, safeBudget))}`}
        />
        <HeroStat label="Tugas aktif" value={String(activeTaskCount)} sub="belum selesai" />
        <HeroStat label="Kebiasaan" value={`${habitsDone}/${habitsTotal}`} sub="hari ini" />
      </div>
    </div>
  );
}

function HeroStat({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div>
      <p className="text-caption text-white/60">{label}</p>
      <p className="num mt-1 text-[20px] font-semibold text-white">{value}</p>
      <p className="text-[11px] text-white/50">{sub}</p>
    </div>
  );
}

function TransactionRow({ tx, wallets }: { tx: Transaction; wallets: Wallet[] }) {
  const isIn = tx.type === 'income' || (tx.type === 'adjustment' && tx.sign === '+');
  const isOut = tx.type === 'expense' || (tx.type === 'adjustment' && tx.sign === '-');
  const Icon = isIn ? ArrowDownLeft : isOut ? ArrowUpRight : ArrowRight;
  const color = isIn ? 'text-success' : isOut ? 'text-danger' : 'text-fg-mid';
  const amountColor = isIn ? 'text-success' : isOut ? 'text-danger' : 'text-fg-mid';
  const sign = isIn ? '+' : isOut ? '-' : '';
  const walletName =
    wallets.find((w) => w.id === tx.wallet_id)?.name ??
    (tx.type === 'transfer' ? 'Transfer' : '—');
  return (
    <li className="flex items-center gap-3 py-2.5">
      <div
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-button bg-surface-3 ${color}`}
      >
        <Icon className="h-4 w-4" strokeWidth={1.75} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-body text-fg-hi">{tx.note || tx.category}</p>
        <p className="text-caption text-fg-lo">
          {tx.category} · {walletName}
        </p>
      </div>
      <p className={`num shrink-0 text-body font-semibold ${amountColor}`}>
        {sign}
        {formatRp(tx.amount)}
      </p>
    </li>
  );
}