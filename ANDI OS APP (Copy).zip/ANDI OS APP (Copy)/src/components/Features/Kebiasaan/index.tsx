import { useMemo, useState } from 'react';
import { Flame, Plus, Repeat, Trash2 } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import type { Habit, HabitFreq } from '../../lib/types';
import { formatNumber, toDateStr, todayStr, uid } from '../../lib/format';
import { habitStreak, habitsDoneToday } from '../../lib/calc/habit';
import { Button } from '../../components/ui/Button';
import { Chip } from '../../components/ui/Chip';
import { Checkbox } from '../../components/ui/Checkbox';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { RingProgress } from '../../components/ui/RingProgress';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { Heatmap } from '../../components/charts/Heatmap';
import { useToast } from '../../components/ui/Toast';

export default function Kebiasaan(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const today = new Date();
  const todayKey = todayStr();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Habit | null>(null);
  const [detail, setDetail] = useState<Habit | null>(null);
  const [deleting, setDeleting] = useState<Habit | null>(null);

  const logsToday = useMemo(
    () => new Set(state.habit_logs.filter((l) => l.date === todayKey).map((l) => l.habit_id)),
    [state.habit_logs, todayKey]
  );

  const done = habitsDoneToday(state.habits, state.habit_logs, today);
  const ratio = state.habits.length > 0 ? done / state.habits.length : 0;

  function toggle(h: Habit) {
    dispatch({ type: 'habitLog:toggle', habitId: h.id, date: todayKey });
    if (!logsToday.has(h.id)) {
      show(`${h.name} selesai hari ini.`);
    }
  }

  function confirmDelete() {
    if (!deleting) return;
    dispatch({ type: 'habit:delete', id: deleting.id });
    show(`Kebiasaan "${deleting.name}" dihapus.`);
    setDeleting(null);
  }

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-micro uppercase text-fg-lo">Kebiasaan</p>
          <h1 className="text-h1 text-fg-hi">Konsistensi yang terukur.</h1>
        </div>
        <Button onClick={openCreate} icon={<Plus className="h-4 w-4" strokeWidth={2} />}>
          Kebiasaan
        </Button>
      </header>

      <Card>
        <div className="flex items-center gap-4">
          <RingProgress value={ratio} size={72}>
            <span className="num text-label text-fg-hi">{done}/{state.habits.length}</span>
          </RingProgress>
          <div className="min-w-0 flex-1">
            <p className="text-h2 text-fg-hi">Hari ini</p>
            <p className="text-caption text-fg-lo">
              {done === state.habits.length && state.habits.length > 0
                ? 'Semua kebiasaan selesai. Kerja bagus.'
                : `${state.habits.length - done} kebiasaan lagi.`}
            </p>
            <ProgressBar value={ratio} className="mt-2" />
          </div>
        </div>
      </Card>

      {state.habits.length === 0 ? (
        <EmptyState
          icon={<Repeat className="h-10 w-10" strokeWidth={1.5} />}
          title="Belum ada kebiasaan."
          description="Mulai dari satu yang paling mudah."
          action={<Button onClick={openCreate}>Kebiasaan pertama</Button>}
        />
      ) : (
        <ul className="flex flex-col gap-2">
          {state.habits.map((h) => {
            const streak = habitStreak(state.habit_logs, h.id, today);
            const isDone = logsToday.has(h.id);
            const last7 = lastSeven(state.habit_logs, h.id);
            return (
              <li key={h.id}>
                <Card padded={false}>
                  <div className="flex items-center gap-3 p-3">
                    <Checkbox
                      checked={isDone}
                      onChange={() => toggle(h)}
                      size="lg"
                      ariaLabel={isDone ? 'Batalkan' : 'Tandai selesai'}
                    />
                    <button
                      type="button"
                      onClick={() => setDetail(h)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <p className={`truncate text-body ${isDone ? 'text-fg-lo line-through' : 'text-fg-hi'}`}>
                        {h.name}
                      </p>
                      <div className="mt-1 flex items-center gap-2 text-caption text-fg-lo">
                        {streak.current >= 3 && (
                          <span className="inline-flex items-center gap-0.5 text-warning">
                            <Flame className="h-3 w-3" strokeWidth={2} />
                            {streak.current}
                          </span>
                        )}
                        <span>{streak.current} hari beruntun</span>
                        <span>·</span>
                        <span>{Math.round(streak.completionRate30)}% 30h</span>
                      </div>
                    </button>
                    <div className="flex shrink-0 items-center gap-1">
                      {last7.map((d) => (
                        <span
                          key={d.date}
                          className={`h-1.5 w-1.5 rounded-full ${d.filled ? 'bg-accent-500' : 'bg-surface-4'}`}
                          title={d.date}
                        />
                      ))}
                    </div>
                  </div>
                </Card>
              </li>
            );
          })}
        </ul>
      )}

      <HabitForm
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        initial={editing}
      />

      <HabitDetail
        habit={detail}
        onClose={() => setDetail(null)}
        onEdit={(h) => { setDetail(null); setEditing(h); setFormOpen(true); }}
        onDelete={(h) => { setDetail(null); setDeleting(h); }}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus kebiasaan ini?"
        description={deleting ? `"${deleting.name}" dan seluruh catatannya akan dihapus.` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

function lastSeven(
  logs: { habit_id: string; date: string }[],
  habitId: string
): { date: string; filled: boolean }[] {
  const set = new Set(logs.filter((l) => l.habit_id === habitId).map((l) => l.date));
  const out: { date: string; filled: boolean }[] = [];
  const d = new Date();
  for (let i = 6; i >= 0; i--) {
    const x = new Date(d);
    x.setDate(x.getDate() - i);
    const ds = toDateStr(x);
    out.push({ date: ds, filled: set.has(ds) });
  }
  return out;
}

function HabitForm({
  open, onClose, initial,
}: {
  open: boolean;
  onClose: () => void;
  initial: Habit | null;
}) {
  const dispatch = useDispatch();
  const { show } = useToast();
  const [name, setName] = useState(initial?.name ?? '');
  const [frequency, setFrequency] = useState<HabitFreq>(initial?.frequency ?? 'daily');
  const [targetPerWeek, setTargetPerWeek] = useState(initial?.target_per_week ? String(initial.target_per_week) : '3');
  const [error, setError] = useState<string | null>(null);

  function submit() {
    if (!name.trim()) {
      setError('Nama kebiasaan wajib diisi.');
      return;
    }
    const payload: Habit = {
      id: initial?.id ?? uid(),
      name: name.trim().slice(0, 40),
      frequency,
      target_per_week: frequency === 'weekly' ? parseInt(targetPerWeek, 10) || 3 : undefined,
      color: initial?.color ?? 'var(--accent-500)',
      created_at: initial?.created_at ?? new Date().toISOString(),
    };
    if (initial) {
      dispatch({ type: 'habit:update', id: initial.id, patch: payload });
      show('Kebiasaan diperbarui.');
    } else {
      dispatch({ type: 'habit:add', habit: payload });
      show('Kebiasaan ditambahkan.');
    }
    setError(null);
    onClose();
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={initial ? 'Ubah kebiasaan' : 'Kebiasaan baru'}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Batal</Button>
          <Button onClick={submit}>{initial ? 'Simpan' : 'Tambah'}</Button>
        </div>
      }
    >
      <div className="flex flex-col gap-3">
        <Input
          label="Nama"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={40}
          error={error ?? undefined}
          autoFocus
        />
        <Select
          label="Frekuensi"
          value={frequency}
          onChange={(e) => setFrequency(e.target.value as HabitFreq)}
        >
          <option value="daily">Setiap hari</option>
          <option value="weekly">Mingguan</option>
          <option value="custom">Custom</option>
        </Select>
        {frequency === 'weekly' && (
          <Input
            label="Target per minggu"
            type="number"
            inputMode="numeric"
            value={targetPerWeek}
            onChange={(e) => setTargetPerWeek(e.target.value)}
          />
        )}
      </div>
    </BottomSheet>
  );
}

function HabitDetail({
  habit, onClose, onEdit, onDelete,
}: {
  habit: Habit | null;
  onClose: () => void;
  onEdit: (h: Habit) => void;
  onDelete: (h: Habit) => void;
}) {
  const state = useAppState();
  const today = new Date();

  const streak = habit ? habitStreak(state.habit_logs, habit.id, today) : null;

  const heatmapDays = useMemo(() => {
    if (!habit) return [];
    const set = new Set(
      state.habit_logs.filter((l) => l.habit_id === habit.id).map((l) => l.date)
    );
    const out: { date: string; value: number }[] = [];
    const cursor = new Date(today);
    for (let i = 89; i >= 0; i--) {
      const d = new Date(cursor);
      d.setDate(d.getDate() - i);
      const ds = toDateStr(d);
      out.push({ date: ds, value: set.has(ds) ? 1 : 0 });
    }
    return out;
  }, [habit, state.habit_logs]);

  if (!habit) return <BottomSheet open={false} onClose={onClose}>{null}</BottomSheet>;

  return (
    <BottomSheet open onClose={onClose} title={habit.name}>
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-3 gap-2">
          <div className="rounded-card-sm border border-line bg-surface-2 p-3">
            <p className="text-micro uppercase text-fg-lo">Streak</p>
            <p className="num mt-1 text-stat-num text-fg-hi">{streak?.current ?? 0}</p>
          </div>
          <div className="rounded-card-sm border border-line bg-surface-2 p-3">
            <p className="text-micro uppercase text-fg-lo">Terpanjang</p>
            <p className="num mt-1 text-stat-num text-fg-hi">{streak?.longest ?? 0}</p>
          </div>
          <div className="rounded-card-sm border border-line bg-surface-2 p-3">
            <p className="text-micro uppercase text-fg-lo">30 hari</p>
            <p className="num mt-1 text-stat-num text-fg-hi">{Math.round(streak?.completionRate30 ?? 0)}%</p>
          </div>
        </div>

        <div>
          <p className="mb-2 text-micro uppercase text-fg-lo">90 hari terakhir</p>
          <div className="overflow-x-auto">
            <Heatmap days={heatmapDays} weeks={13} maxValue={1} cellSize={12} />
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => onEdit(habit)} fullWidth>Ubah</Button>
          <Button variant="danger" onClick={() => onDelete(habit)} fullWidth icon={<Trash2 className="h-4 w-4" strokeWidth={2} />}>
            Hapus
          </Button>
        </div>

        <p className="text-center text-caption text-fg-dim">
          Total {formatNumber(state.habit_logs.filter((l) => l.habit_id === habit.id).length)} catatan
        </p>
      </div>
    </BottomSheet>
  );
}