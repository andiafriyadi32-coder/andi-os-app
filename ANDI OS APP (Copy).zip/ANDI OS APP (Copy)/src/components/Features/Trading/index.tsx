import { useMemo, useState } from 'react';
import { AlertCircle, Plus, TrendingUp, Trash2 } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import type { Trade } from '../../lib/types';
import { formatRp, formatRelative, uid } from '../../lib/format';
import { isRevengeTrade, tradeStats } from '../../lib/calc/trading';
import { Button } from '../../components/ui/Button';
import { Chip } from '../../components/ui/Chip';
import { Input } from '../../components/ui/Input';
import { Textarea } from '../../components/ui/Textarea';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { StatCard } from '../../components/ui/StatCard';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { LineChart, type LinePoint } from '../../components/charts/LineChart';
import { useToast } from '../../components/ui/Toast';

type Filter = 'all' | 'profit' | 'loss' | 'be';

const EMOTIONS = ['tenang', 'ragu', 'cemas', 'fomo', 'serakah', 'panik'];

function toLocalDatetime(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function Trading(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [filter, setFilter] = useState<Filter>('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Trade | null>(null);
  const [deleting, setDeleting] = useState<Trade | null>(null);

  const stats = useMemo(() => tradeStats(state.trades), [state.trades]);

  const filtered = useMemo(() => {
    const list = filter === 'all' ? state.trades : state.trades.filter((t) => t.result === filter);
    return [...list].sort((a, b) => b.datetime.localeCompare(a.datetime));
  }, [state.trades, filter]);

  const equityCurve = useMemo<LinePoint[]>(() => {
    return stats.cumulativeR.map((v, i) => ({ label: String(i + 1), value: v }));
  }, [stats.cumulativeR]);

  function confirmDelete() {
    if (!deleting) return;
    const snapshot = deleting;
    dispatch({ type: 'trade:delete', id: snapshot.id });
    setDeleting(null);
    show('Trade dihapus.', {
      action: {
        label: 'Urungkan',
        onClick: () => dispatch({ type: 'trade:add', trade: snapshot }),
      },
      duration: 5000,
    });
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-micro uppercase text-fg-lo">Trading</p>
          <h1 className="text-h1 text-fg-hi">Jurnal dengan statistik proses.</h1>
        </div>
        <Button
          onClick={() => { setEditing(null); setFormOpen(true); }}
          icon={<Plus className="h-4 w-4" strokeWidth={2} />}
        >
          Trade
        </Button>
      </header>

      <Card>
        <p className="text-micro uppercase text-fg-lo">Total P/L</p>
        <p
          className={`num mt-1 text-hero-num ${
            stats.totalPl > 0 ? 'text-success' : stats.totalPl < 0 ? 'text-danger' : 'text-fg-hi'
          }`}
        >
          {stats.totalPl >= 0 ? '+' : ''}
          {formatRp(stats.totalPl)}
        </p>
        <p className="mt-1 text-caption text-fg-lo">
          {stats.wins}P · {stats.losses}L · {stats.bes}BE
        </p>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard
          label="Win rate"
          value={`${stats.winRate.toFixed(1)}%`}
          tone={stats.winRate >= 50 ? 'success' : 'default'}
        />
        <StatCard
          label="Avg RR"
          value={stats.avgRR == null ? '—' : stats.avgRR.toFixed(2)}
        />
        <StatCard
          label="Profit factor"
          value={stats.profitFactor == null ? '—' : stats.profitFactor.toFixed(2)}
          tone={stats.profitFactor != null && stats.profitFactor >= 1.5 ? 'success' : 'default'}
        />
        <StatCard
          label="Max DD"
          value={`${stats.maxDrawdown.toFixed(2)}R`}
          tone={stats.maxDrawdown > 5 ? 'danger' : 'default'}
        />
      </div>

      <Card>
        <p className="mb-3 text-micro uppercase text-fg-lo">Equity curve (R)</p>
        {equityCurve.length === 0 ? (
          <p className="py-8 text-center text-caption text-fg-lo">
            Grafik muncul setelah ada trade.
          </p>
        ) : (
          <LineChart data={equityCurve} height={140} tone={stats.totalPl >= 0 ? 'success' : 'danger'} />
        )}
        <div className="mt-3 flex items-center justify-between text-caption text-fg-lo">
          <span>Expectancy</span>
          <span className="num text-fg-hi">{stats.expectancy.toFixed(2)}R per trade</span>
        </div>
      </Card>

      <div className="flex flex-wrap gap-1.5">
        <Chip active={filter === 'all'} onClick={() => setFilter('all')}>Semua</Chip>
        <Chip active={filter === 'profit'} onClick={() => setFilter('profit')}>Profit</Chip>
        <Chip active={filter === 'loss'} onClick={() => setFilter('loss')}>Loss</Chip>
        <Chip active={filter === 'be'} onClick={() => setFilter('be')}>BE</Chip>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<TrendingUp className="h-10 w-10" strokeWidth={1.5} />}
          title="Belum ada trade tercatat."
          description="Disiplin dimulai dari sini."
          action={<Button onClick={() => { setEditing(null); setFormOpen(true); }}>Catat trade</Button>}
        />
      ) : (
        <ul className="flex flex-col gap-2">
          {filtered.map((t) => {
            const revenge = isRevengeTrade(t, state.trades);
            return (
              <li key={t.id}>
                <Card padded={false}>
                  <button
                    type="button"
                    onClick={() => { setEditing(t); setFormOpen(true); }}
                    className="w-full p-4 text-left"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-h2 text-fg-hi">{t.pair}</p>
                          <span
                            className={`rounded-chip px-1.5 py-0.5 text-[10px] font-semibold uppercase ${
                              t.direction === 'buy' ? 'bg-success/15 text-success' : 'bg-danger/15 text-danger'
                            }`}
                          >
                            {t.direction}
                          </span>
                          {revenge && (
                            <span className="inline-flex items-center gap-0.5 rounded-chip bg-warning/15 px-1.5 py-0.5 text-[10px] font-semibold text-warning">
                              <AlertCircle className="h-2.5 w-2.5" strokeWidth={3} />
                              Revenge?
                            </span>
                          )}
                        </div>
                        <p className="mt-1 text-caption text-fg-lo">
                          {t.setup ?? '—'} · {formatRelative(new Date(t.datetime))}
                          {t.r != null ? ` · ${t.r > 0 ? '+' : ''}${t.r.toFixed(2)}R` : ''}
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p
                          className={`num text-body font-semibold ${
                            t.result === 'profit' ? 'text-success' : t.result === 'loss' ? 'text-danger' : 'text-fg-mid'
                          }`}
                        >
                          {t.pl >= 0 ? '+' : ''}
                          {formatRp(t.pl)}
                        </p>
                      </div>
                    </div>
                  </button>
                  <div className="flex justify-end border-t border-line-subtle px-2 py-1">
                    <button
                      type="button"
                      onClick={() => setDeleting(t)}
                      className="rounded-button p-1.5 text-fg-lo hover:text-danger"
                      aria-label="Hapus"
                    >
                      <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
                    </button>
                  </div>
                </Card>
              </li>
            );
          })}
        </ul>
      )}

      <TradeForm
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        initial={editing}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus trade ini?"
        description={deleting ? `${deleting.pair} ${deleting.direction} — ${formatRp(deleting.pl)}` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

function TradeForm({
  open, onClose, initial,
}: {
  open: boolean;
  onClose: () => void;
  initial: Trade | null;
}) {
  const dispatch = useDispatch();
  const { show } = useToast();

  const [datetime, setDatetime] = useState(
    initial ? toLocalDatetime(new Date(initial.datetime)) : toLocalDatetime(new Date())
  );
  const [pair, setPair] = useState(initial?.pair ?? '');
  const [direction, setDirection] = useState<'buy' | 'sell'>(initial?.direction ?? 'buy');
  const [entry, setEntry] = useState(initial?.entry != null ? String(initial.entry) : '');
  const [sl, setSl] = useState(initial?.sl != null ? String(initial.sl) : '');
  const [tp, setTp] = useState(initial?.tp != null ? String(initial.tp) : '');
  const [exit, setExit] = useState(initial?.exit != null ? String(initial.exit) : '');
  const [lot, setLot] = useState(initial?.lot != null ? String(initial.lot) : '0.01');
  const [pl, setPl] = useState(initial?.pl != null ? String(initial.pl) : '');
  const [result, setResult] = useState<'profit' | 'loss' | 'be'>(initial?.result ?? 'profit');
  const [setup, setSetup] = useState(initial?.setup ?? '');
  const [timeframe, setTimeframe] = useState(initial?.timeframe ?? '');
  const [session, setSession] = useState(initial?.session ?? '');
  const [emotion, setEmotion] = useState(initial?.emotion ?? '');
  const [notes, setNotes] = useState(initial?.notes ?? '');
  const [error, setError] = useState<string | null>(null);

  const autoR = useMemo(() => {
    const e = parseFloat(entry);
    const s = parseFloat(sl);
    const l = parseFloat(lot);
    const p = parseFloat(pl);
    if ([e, s, l, p].some((x) => Number.isNaN(x))) return null;
    const risk = Math.abs(e - s) * l * 100_000;
    if (risk <= 0) return null;
    return Math.round((p / risk) * 100) / 100;
  }, [entry, sl, lot, pl]);

  function submit() {
    const dt = new Date(datetime);
    if (Number.isNaN(dt.getTime())) { setError('Tanggal tidak valid.'); return; }
    if (!pair.trim()) { setError('Pair wajib diisi.'); return; }
    const p = parseFloat(pl);
    if (Number.isNaN(p)) { setError('P/L wajib diisi.'); return; }
    const l = parseFloat(lot);
    if (Number.isNaN(l) || l <= 0) { setError('Lot harus lebih dari nol.'); return; }

    const payload: Trade = {
      id: initial?.id ?? uid(),
      datetime: dt.toISOString(),
      pair: pair.trim().toUpperCase(),
      direction,
      entry: entry ? parseFloat(entry) : undefined,
      sl: sl ? parseFloat(sl) : undefined,
      tp: tp ? parseFloat(tp) : undefined,
      exit: exit ? parseFloat(exit) : undefined,
      lot: l,
      pl: Math.round(p),
      r: autoR ?? undefined,
      result,
      setup: setup.trim() || undefined,
      timeframe: timeframe.trim() || undefined,
      session: session.trim() || undefined,
      emotion: emotion || undefined,
      notes: notes.trim() || undefined,
      created_at: initial?.created_at ?? new Date().toISOString(),
    };
    if (initial) {
      dispatch({ type: 'trade:update', id: initial.id, patch: payload });
      show('Trade diperbarui.');
    } else {
      dispatch({ type: 'trade:add', trade: payload });
      show('Trade tercatat.');
    }
    setError(null);
    onClose();
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={initial ? 'Ubah trade' : 'Trade baru'}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Batal</Button>
          <Button onClick={submit}>{initial ? 'Simpan' : 'Catat'}</Button>
        </div>
      }
    >
      <div className="flex flex-col gap-3">
        <Input label="Waktu" type="datetime-local" value={datetime} onChange={(e) => setDatetime(e.target.value)} error={error ?? undefined} />
        <div className="grid grid-cols-2 gap-2">
          <Input label="Pair" value={pair} onChange={(e) => setPair(e.target.value)} placeholder="XAUUSD" />
          <div>
            <p className="mb-1.5 text-label text-fg-mid">Arah</p>
            <div className="flex gap-1">
              <Chip active={direction === 'buy'} onClick={() => setDirection('buy')}>BUY</Chip>
              <Chip active={direction === 'sell'} onClick={() => setDirection('sell')}>SELL</Chip>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Input label="Entry" type="number" step="any" value={entry} onChange={(e) => setEntry(e.target.value)} />
          <Input label="SL" type="number" step="any" value={sl} onChange={(e) => setSl(e.target.value)} />
          <Input label="TP" type="number" step="any" value={tp} onChange={(e) => setTp(e.target.value)} />
          <Input label="Exit" type="number" step="any" value={exit} onChange={(e) => setExit(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Input label="Lot" type="number" step="0.01" value={lot} onChange={(e) => setLot(e.target.value)} />
          <Input label="P/L (Rp)" type="number" value={pl} onChange={(e) => setPl(e.target.value)} />
        </div>
        {autoR != null && (
          <div className="rounded-card-sm border border-line bg-surface-2 px-3 py-2">
            <p className="text-caption text-fg-lo">R multiple (otomatis)</p>
            <p className="num text-label text-fg-hi">{autoR > 0 ? '+' : ''}{autoR.toFixed(2)}R</p>
          </div>
        )}
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Hasil</p>
          <div className="flex gap-1">
            <Chip active={result === 'profit'} onClick={() => setResult('profit')} tone="success">Profit</Chip>
            <Chip active={result === 'loss'} onClick={() => setResult('loss')} tone="danger">Loss</Chip>
            <Chip active={result === 'be'} onClick={() => setResult('be')}>BE</Chip>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Input label="Setup" value={setup} onChange={(e) => setSetup(e.target.value)} placeholder="Breakout" />
          <Input label="Timeframe" value={timeframe} onChange={(e) => setTimeframe(e.target.value)} placeholder="M15" />
          <Input label="Sesi" value={session} onChange={(e) => setSession(e.target.value)} placeholder="Asia" />
        </div>
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Emosi</p>
          <div className="flex flex-wrap gap-1">
            {EMOTIONS.map((em) => (
              <Chip key={em} active={emotion === em} onClick={() => setEmotion(emotion === em ? '' : em)}>
                {em}
              </Chip>
            ))}
          </div>
        </div>
        <Textarea label="Catatan" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
    </BottomSheet>
  );
}