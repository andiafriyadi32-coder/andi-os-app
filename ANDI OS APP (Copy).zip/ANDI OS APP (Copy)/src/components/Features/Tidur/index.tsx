import { useMemo, useState } from 'react';
import { AlertTriangle, Moon, Plus, Trash2 } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import type { SleepLog } from '../../lib/types';
import { formatDateShort, formatDateFull, formatRelative, toDateStr, uid } from '../../lib/format';
import { sleepDuration, sleepStats } from '../../lib/calc/sleep';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Textarea } from '../../components/ui/Textarea';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { StatCard } from '../../components/ui/StatCard';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { BarChart, type BarPoint } from '../../components/charts/BarChart';
import { useToast } from '../../components/ui/Toast';

function hoursMin(min: number): string {
  const h = Math.floor(min / 60);
  const m = min % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}j`;
  return `${h}j ${m}m`;
}

function toLocalDatetime(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function Tidur(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<SleepLog | null>(null);
  const [deleting, setDeleting] = useState<SleepLog | null>(null);

  const today = new Date();
  const stats = useMemo(() => sleepStats(state.sleep_logs, today), [state.sleep_logs]);

  const sorted = useMemo(
    () =>
      [...state.sleep_logs].sort(
        (a, b) => new Date(b.wake_at).getTime() - new Date(a.wake_at).getTime()
      ),
    [state.sleep_logs]
  );

  const chartData = useMemo<BarPoint[]>(() => {
    const out: BarPoint[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const ds = toDateStr(d);
      const log = state.sleep_logs.find((l) => toDateStr(new Date(l.wake_at)) === ds);
      const hours = log ? log.duration_min / 60 : 0;
      out.push({
        label: String(d.getDate()),
        value: hours,
        tone: hours >= 7 ? 'success' : hours > 0 && hours < 6 ? 'danger' : 'accent',
      });
    }
    return out;
  }, [state.sleep_logs]);

  function confirmDelete() {
    if (!deleting) return;
    const snapshot = deleting;
    dispatch({ type: 'sleep:delete', id: snapshot.id });
    setDeleting(null);
    show('Catatan tidur dihapus.', {
      action: {
        label: 'Urungkan',
        onClick: () => dispatch({ type: 'sleep:add', log: snapshot }),
      },
      duration: 5000,
    });
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-micro uppercase text-fg-lo">Tidur</p>
          <h1 className="text-h1 text-fg-hi">Fondasi performa shift.</h1>
        </div>
        <Button
          onClick={() => { setEditing(null); setFormOpen(true); }}
          icon={<Plus className="h-4 w-4" strokeWidth={2} />}
        >
          Log
        </Button>
      </header>

      {stats.belowThreshold && (
        <div className="flex items-start gap-2 rounded-card border border-warning/30 bg-warning/10 p-3">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" strokeWidth={2} />
          <p className="text-caption text-fg-mid">
            Rata-rata tidur 7 hari terakhir {hoursMin(Math.round(stats.avg7))}. Kurang dari 7 jam — pertimbangkan tidur lebih awal malam ini.
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard
          label="Rata-rata 7 hari"
          value={stats.avg7 > 0 ? hoursMin(Math.round(stats.avg7)) : '—'}
          tone={stats.belowThreshold ? 'warning' : 'default'}
        />
        <StatCard
          label="Rata-rata 14 hari"
          value={stats.avg14 > 0 ? hoursMin(Math.round(stats.avg14)) : '—'}
        />
        <StatCard
          label="Total minggu ini"
          value={stats.totalWeek > 0 ? hoursMin(stats.totalWeek) : '—'}
        />
      </div>

      <Card>
        <p className="mb-3 text-micro uppercase text-fg-lo">14 hari terakhir</p>
        <BarChart data={chartData} height={120} />
        <p className="mt-2 text-center text-caption text-fg-dim">Jam tidur per hari.</p>
      </Card>

      {sorted.length === 0 ? (
        <EmptyState
          icon={<Moon className="h-10 w-10" strokeWidth={1.5} />}
          title="Belum ada catatan tidur."
          description="Catat jam tidur dan bangun untuk melihat pola."
          action={
            <Button onClick={() => { setEditing(null); setFormOpen(true); }}>
              Log pertama
            </Button>
          }
        />
      ) : (
        <ul className="flex flex-col gap-2">
          {sorted.map((l) => (
            <li key={l.id}>
              <Card padded={false}>
                <button
                  type="button"
                  onClick={() => { setEditing(l); setFormOpen(true); }}
                  className="flex w-full items-center gap-3 p-4 text-left"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-button bg-accent-50 text-accent-500">
                    <Moon className="h-5 w-5" strokeWidth={1.75} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="num text-h2 text-fg-hi">{hoursMin(l.duration_min)}</p>
                    <p className="text-caption text-fg-lo">
                      {formatDateShort(new Date(l.wake_at))} · kualitas {l.quality}/5
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); setDeleting(l); }}
                    className="rounded-button p-1.5 text-fg-lo hover:bg-surface-3 hover:text-danger"
                    aria-label="Hapus"
                  >
                    <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                  </button>
                </button>
              </Card>
            </li>
          ))}
        </ul>
      )}

      <SleepForm
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        initial={editing}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus catatan tidur ini?"
        description={deleting ? `Tidur ${formatDateFull(new Date(deleting.sleep_at))}.` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

function SleepForm({
  open, onClose, initial,
}: {
  open: boolean;
  onClose: () => void;
  initial: SleepLog | null;
}) {
  const dispatch = useDispatch();
  const { show } = useToast();

  const defaultSleep = new Date();
  defaultSleep.setDate(defaultSleep.getDate() - 1);
  defaultSleep.setHours(22, 0, 0, 0);
  const defaultWake = new Date();
  defaultWake.setHours(6, 0, 0, 0);

  const [sleepAt, setSleepAt] = useState(
    initial ? toLocalDatetime(new Date(initial.sleep_at)) : toLocalDatetime(defaultSleep)
  );
  const [wakeAt, setWakeAt] = useState(
    initial ? toLocalDatetime(new Date(initial.wake_at)) : toLocalDatetime(defaultWake)
  );
  const [quality, setQuality] = useState<1 | 2 | 3 | 4 | 5>(initial?.quality ?? 3);
  const [notes, setNotes] = useState(initial?.notes ?? '');
  const [error, setError] = useState<string | null>(null);

  function submit() {
    const sleepDate = new Date(sleepAt);
    const wakeDate = new Date(wakeAt);
    if (Number.isNaN(sleepDate.getTime()) || Number.isNaN(wakeDate.getTime())) {
      setError('Waktu tidak valid.');
      return;
    }
    const dur = sleepDuration(sleepDate, wakeDate);
    if (dur <= 0 || dur > 24 * 60) {
      setError('Durasi harus antara 1 menit sampai 24 jam.');
      return;
    }
    const payload: SleepLog = {
      id: initial?.id ?? uid(),
      sleep_at: sleepDate.toISOString(),
      wake_at: wakeDate.toISOString(),
      duration_min: dur,
      quality,
      notes: notes.trim() || undefined,
      created_at: initial?.created_at ?? new Date().toISOString(),
    };
    if (initial) {
      dispatch({ type: 'sleep:update', id: initial.id, patch: payload });
      show('Catatan tidur diperbarui.');
    } else {
      dispatch({ type: 'sleep:add', log: payload });
      show('Catatan tidur disimpan.');
    }
    setError(null);
    onClose();
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={initial ? 'Ubah catatan tidur' : 'Catat tidur'}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Batal</Button>
          <Button onClick={submit}>{initial ? 'Simpan' : 'Tambah'}</Button>
        </div>
      }
    >
      <div className="flex flex-col gap-3">
        <Input
          label="Mulai tidur"
          type="datetime-local"
          value={sleepAt}
          onChange={(e) => setSleepAt(e.target.value)}
          error={error ?? undefined}
        />
        <Input
          label="Bangun"
          type="datetime-local"
          value={wakeAt}
          onChange={(e) => setWakeAt(e.target.value)}
        />
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Kualitas</p>
          <div className="flex gap-1">
            {([1, 2, 3, 4, 5] as const).map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => setQuality(q)}
                className={`h-10 flex-1 rounded-button border text-label font-medium transition-colors ${
                  quality === q
                    ? 'border-accent-500 bg-accent-500 text-white'
                    : 'border-line bg-surface-2 text-fg-mid hover:border-line-strong'
                }`}
              >
                {q}
              </button>
            ))}
          </div>
        </div>
        <Textarea
          label="Catatan"
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
    </BottomSheet>
  );
}

void formatRelative;